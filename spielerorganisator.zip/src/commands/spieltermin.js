const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const db = require('../db/database');
const { isAdminInteraction } = require('../utils/permissions');
const {
  displayName,
  formatRosterGroups,
  normalizeRosterStatus,
  opggRegion,
  positionMatchesRole,
  rosterSortRank,
  rosterStatusLabel
} = require('../utils/rosterUtils');
const { getTeamById, resolveTeamForInteraction } = require('../services/teamService');

const ROLE_ORDER = ['Top', 'Jgl', 'Mid', 'ADC', 'Supp', 'Sub1', 'Sub2'];
const STARTER_ROLES = ['Top', 'Jgl', 'Mid', 'ADC', 'Supp'];
const STATUS_VALUES = ['pending', 'fixed', 'cancelled'];
const EVENT_TYPE_VALUES = ['open', 'flex', 'scrim', 'primeleague', 'other'];

function isValidTime(value) {
  if (!/^\d{2}:\d{2}$/.test(value)) return false;

  const [hours, minutes] = value.split(':').map(Number);
  return hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59;
}

function isValidIsoDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;

  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));

  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function parseDateInput(value) {
  if (!value) return null;

  const trimmed = value.trim();

  if (isValidIsoDate(trimmed)) {
    return trimmed;
  }

  if (/^\d{2}\.\d{2}\.\d{4}$/.test(trimmed)) {
    const [day, month, year] = trimmed.split('.');
    const iso = `${year}-${month}-${day}`;
    return isValidIsoDate(iso) ? iso : null;
  }

  return null;
}

function parseTimeToMinutes(timeStr) {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
}

function minutesToTime(minutes) {
  const hours = String(Math.floor(minutes / 60)).padStart(2, '0');
  const mins = String(minutes % 60).padStart(2, '0');
  return `${hours}:${mins}`;
}

function addMinutesToTime(timeStr, minutesToAdd) {
  return minutesToTime(parseTimeToMinutes(timeStr) + minutesToAdd);
}

function formatDateDE(dateStr) {
  const [year, month, day] = dateStr.split('-');
  return `${day}.${month}.${year}`;
}

function formatDateTimeDE(dateTime) {
  if (!dateTime) return '-';
  const [dateStr, timeStr] = dateTime.split(' ');
  return `${formatDateDE(dateStr)}, ${timeStr}`;
}

function formatDateLongDE(dateStr) {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Intl.DateTimeFormat('de-DE', {
    timeZone: 'UTC',
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(new Date(Date.UTC(year, month - 1, day)));
}

function statusLabel(status) {
  switch (status) {
    case 'fixed':
      return 'Fixed';
    case 'cancelled':
      return 'Cancelled';
    default:
      return 'Pending';
  }
}

function statusEmoji(status) {
  switch (status) {
    case 'fixed':
      return '🟢';
    case 'cancelled':
      return '🔴';
    default:
      return '🟡';
  }
}

function statusColor(status) {
  switch (status) {
    case 'fixed':
      return 0x57f287;
    case 'cancelled':
      return 0xed4245;
    default:
      return 0xfee75c;
  }
}

function eventTypeLabel(type) {
  switch (type) {
    case 'open':
      return 'Offen';
    case 'flex':
      return 'Flex';
    case 'primeleague':
      return 'Primeleague';
    case 'scrim':
      return 'Scrim';
    default:
      return 'Sonstiges';
  }
}

function normalizeStatusInput(value) {
  const normalized = String(value || '').trim().toLowerCase();

  if (['pending', 'offen', 'open'].includes(normalized)) return 'pending';
  if (['fixed', 'fix', 'fest', 'bestätigt', 'bestaetigt'].includes(normalized)) return 'fixed';
  if (['cancelled', 'canceled', 'abgesagt', 'cancel'].includes(normalized)) return 'cancelled';

  return null;
}

function normalizeEventTypeInput(value) {
  const normalized = String(value || '').trim().toLowerCase().replace(/\s+/g, '');

  if (['open', 'offen', 'unklar'].includes(normalized)) return 'open';
  if (['flex', 'flexqueue', 'flexq'].includes(normalized)) return 'flex';
  if (['scrim', 'scrims', 'training'].includes(normalized)) return 'scrim';
  if (['primeleague', 'prm', 'prime'].includes(normalized)) return 'primeleague';
  if (['other', 'sonstiges', 'sonstig'].includes(normalized)) return 'other';

  return null;
}

function buildStatusModal(eventId, messageId, currentStatus) {
  const modal = new ModalBuilder()
    .setCustomId(`spieltermin:statusmodal:${eventId}:${messageId}`)
    .setTitle(`Status – #${eventId}`);

  const input = new TextInputBuilder()
    .setCustomId('status_value')
    .setLabel('Status: pending, fixed oder cancelled')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setValue(currentStatus || 'pending')
    .setPlaceholder('pending / fixed / cancelled');

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function buildTypeModal(eventId, messageId, currentType) {
  const modal = new ModalBuilder()
    .setCustomId(`spieltermin:typemodal:${eventId}:${messageId}`)
    .setTitle(`Typ – #${eventId}`);

  const input = new TextInputBuilder()
    .setCustomId('event_type_value')
    .setLabel('Typ: open, flex, scrim, primeleague, other')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setValue(currentType || 'open')
    .setPlaceholder('open / flex / scrim / primeleague / other');

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function getMeetingOffsetMinutes(type) {
  switch (type) {
    case 'scrim':
      return -15;
    case 'primeleague':
      return -30;
    default:
      return null;
  }
}

function getDurationMinutesFromDateTimes(startAt, endAt) {
  if (!startAt || !endAt) return 150;

  const startMinutes = parseTimeToMinutes(startAt.slice(11, 16));
  const endMinutes = parseTimeToMinutes(endAt.slice(11, 16));
  const diff = endMinutes - startMinutes;

  return diff > 0 ? diff : 150;
}

function getDefaultMeetingAtFromScheduledStart(scheduledStartAt, type) {
  if (!scheduledStartAt) return null;

  const offset = getMeetingOffsetMinutes(type);
  if (offset === null) return null;

  const dateStr = scheduledStartAt.slice(0, 10);
  const startTime = scheduledStartAt.slice(11, 16);

  return `${dateStr} ${addMinutesToTime(startTime, offset)}`;
}

function getEffectiveMeetingAt(event, type) {
  if (type === 'scrim') {
    return event.meeting_scrim_at || getDefaultMeetingAtFromScheduledStart(event.scheduled_start_at, 'scrim');
  }

  if (type === 'primeleague') {
    return event.meeting_primeleague_at || getDefaultMeetingAtFromScheduledStart(event.scheduled_start_at, 'primeleague');
  }

  return null;
}

function getLegacyMeetingAtForCreate(eventType, startAt, meetingScrimAt, meetingPrimeleagueAt) {
  if (eventType === 'scrim') {
    return meetingScrimAt || startAt;
  }

  if (eventType === 'primeleague') {
    return meetingPrimeleagueAt || startAt;
  }

  return startAt;
}

function buildMeetingFieldValue(event) {
  if (!event.scheduled_start_at) {
    return '-';
  }

  if (event.event_type === 'scrim') {
    return formatDateTimeDE(getEffectiveMeetingAt(event, 'scrim'));
  }

  if (event.event_type === 'primeleague') {
    return formatDateTimeDE(getEffectiveMeetingAt(event, 'primeleague'));
  }

  const scrimMeeting = formatDateTimeDE(getEffectiveMeetingAt(event, 'scrim'));
  const primeMeeting = formatDateTimeDE(getEffectiveMeetingAt(event, 'primeleague'));

  return `Scrim: ${scrimMeeting}\nPrime League: ${primeMeeting}`;
}

function reconcileMeetingAfterScheduleChange(currentMeetingAt, previousScheduledStartAt, nextScheduledStartAt, type) {
  if (!nextScheduledStartAt) return null;

  const newDefault = getDefaultMeetingAtFromScheduledStart(nextScheduledStartAt, type);
  if (!currentMeetingAt) return newDefault;

  const oldDefault = previousScheduledStartAt
    ? getDefaultMeetingAtFromScheduledStart(previousScheduledStartAt, type)
    : null;

  if (!oldDefault || currentMeetingAt === oldDefault) {
    return newDefault;
  }

  const nextDate = nextScheduledStartAt.slice(0, 10);
  const currentTime = currentMeetingAt.slice(11, 16);

  return `${nextDate} ${currentTime}`;
}

function playerDisplay(row) {
  return displayName(row);
}

function assignmentTypeLabel(item) {
  if (item.assignee_type === 'standin') return 'Standin';
  if (item.assignee_type === 'manual') return 'Manuell';
  return rosterStatusLabel(item.roster_status || 'sub');
}

function assignmentDisplayLabel(item) {
  const suffix = item.assignee_type === 'standin'
    ? ' [Standin]'
    : item.assignee_type === 'manual'
      ? ' [manuell]'
      : '';
  return `${item.player_label}${suffix}`;
}

function truncateField(value, maxLength = 1000) {
  if (!value) return '-';
  return value.length > maxLength ? `${value.slice(0, maxLength - 1)}…` : value;
}

function buildLineupText(assignments) {
  if (!assignments.length) return '-';

  const rank = new Map(ROLE_ORDER.map((label, index) => [label, index]));

  return assignments
    .slice()
    .sort((a, b) => {
      const aRank = rank.has(a.role_label) ? rank.get(a.role_label) : 999;
      const bRank = rank.has(b.role_label) ? rank.get(b.role_label) : 999;
      return aRank - bRank || a.role_label.localeCompare(b.role_label, 'de');
    })
    .map(item => `${item.role_label}: ${assignmentDisplayLabel(item)}`)
    .join(' | ');
}

function buildCompactAvailablePlayersText(value) {
  const raw = String(value || '').trim();
  if (!raw || raw === '-') return 'Noch nicht ermittelt';

  const names = [];
  const seen = new Set();

  for (const line of raw.split(/\r?\n/)) {
    const normalized = line.replace(/\*\*/g, '').trim();
    const match = normalized.match(/^[•*-]\s*([^:]+):/);
    if (!match) continue;

    const name = match[1].trim();
    const key = name.toLocaleLowerCase('de-DE');
    if (!name || seen.has(key)) continue;

    seen.add(key);
    names.push(name);
  }

  if (names.length) {
    return truncateField(names.join(', '));
  }

  return truncateField(raw.replace(/\s*\n\s*/g, ', '));
}

function buildMissingStarterRolesText(assignments) {
  const filledRoles = new Set(
    assignments
      .filter(item => STARTER_ROLES.includes(item.role_label) && String(item.player_label || '').trim())
      .map(item => item.role_label)
  );

  const missingRoles = STARTER_ROLES.filter(role => !filledRoles.has(role));
  return missingRoles.length ? missingRoles.join(', ') : 'Keine';
}

function buildAvailablePlayersForCard(event) {
  if (!event.scheduled_start_at || !event.scheduled_end_at) {
    return buildCompactAvailablePlayersText(event.available_players_text);
  }

  const players = db.prepare(`
    SELECT id, discord_user_id, username, global_name, alias
    FROM players
    WHERE is_archived = 0
      AND roster_status IN ('main', 'sub')
      AND (? IS NULL OR team_id = ?)
    ORDER BY COALESCE(alias, global_name, username) COLLATE NOCASE ASC
  `).all(event.team_id ?? null, event.team_id ?? null);

  const availableNames = players
    .filter(player => isPlayerAvailableForEvent(player.id, event))
    .map(playerDisplay);

  return availableNames.length ? truncateField(availableNames.join(', ')) : 'Keine';
}

function formatTimeOnly(dateTime) {
  if (!dateTime) return '-';
  return dateTime.slice(11, 16);
}

function formatTimeOnlyLabel(dateTime) {
  const time = formatTimeOnly(dateTime);
  return time === '-' ? '-' : `${time} Uhr`;
}

function buildStarterLineupText(assignments) {
  const starterRoles = ['Top', 'Jgl', 'Mid', 'ADC', 'Supp'];
  const byRole = new Map(assignments.map(item => [item.role_label, item.player_label]));

  return starterRoles
    .map(role => `**${role}:** ${byRole.get(role) || '-'}`)
    .join('\n');
}

function getDisplayStartAt(event) {
  return event.scheduled_start_at || event.window_start_at || null;
}

function getDisplayMeetingAt(event) {
  if (event.event_type === 'scrim' || event.event_type === 'primeleague') {
    return getEffectiveMeetingAt(event, event.event_type);
  }

  return null;
}

function buildPlayerCalendarStatusLabel(status) {
  switch (status) {
    case 'fixed':
      return '✅ Fixiert';
    case 'cancelled':
      return '⛔ Cancelled';
    case 'pending':
    default:
      return '🟡 Pending';
  }
}

function buildPlayerCalendarTitle(event) {
  const opponent = event.opponent_name?.trim();

  return `📅 Termin ${formatDateLongDE(event.option_date)}${opponent ? ` vs ${opponent}` : ''}`;
}

function buildPlayerCalendarDescription(event, assignments) {
  const startAt = getDisplayStartAt(event);
  const meetingAt = getDisplayMeetingAt(event);
  const teamOpgg = buildTeamOpggInfo(assignments);

  return [
    `${buildPlayerCalendarStatusLabel(event.status)}`,
    `Anpfiff: ${formatTimeOnlyLabel(startAt)}`,
    `Treffpunkt: ${formatTimeOnlyLabel(meetingAt)}`,
    '',
    buildStarterLineupText(assignments),
    '',
    teamOpgg.ok ? `[OP.GG öffnen](${teamOpgg.url})` : 'OP.GG öffnen: -',
    '',
    event.opgg_url ? `[Gegner OP.GG](${event.opgg_url})` : 'Gegner OP.GG: -',
    '',
    'Hinweis',
    event.note?.trim() || '-'
  ].join('\n');
}

function findPlayerByLabel(label, teamId = null) {
  if (!label) return null;
  const trimmed = label.trim();
  if (!trimmed) return null;

  const players = db.prepare(`
    SELECT *
    FROM players
    WHERE is_archived = 0
      AND (? IS NULL OR team_id = ?)
    ORDER BY id ASC
  `).all(teamId, teamId);

  const lower = trimmed.toLowerCase();

  return (
    players.find(player => player.alias && player.alias.trim().toLowerCase() === lower) ||
    players.find(player => player.global_name && player.global_name.trim().toLowerCase() === lower) ||
    players.find(player => player.username && player.username.trim().toLowerCase() === lower) ||
    players.find(player => player.discord_user_id === trimmed) ||
    null
  );
}

function findStandinByLabel(label) {
  if (!label) return null;
  const trimmed = label.trim();
  if (!trimmed) return null;

  const lower = trimmed.toLowerCase();
  const standins = db.prepare(`
    SELECT *
    FROM standins
    WHERE is_active = 1
    ORDER BY id ASC
  `).all();

  return (
    standins.find(standin => standin.display_name && standin.display_name.trim().toLowerCase() === lower) ||
    standins.find(standin => `${standin.riot_game_name}#${standin.riot_tag}`.trim().toLowerCase() === lower) ||
    null
  );
}

function getEventById(id) {
  return db.prepare(`
    SELECT *
    FROM team_calendar_events
    WHERE id = ?
  `).get(id);
}

function getAssignments(eventId) {
  return db.prepare(`
    SELECT
      a.id,
      a.event_id,
      a.role_label,
      a.player_label,
      a.assignee_type,
      a.player_id,
      a.standin_id,
      p.discord_user_id,
      p.username,
      p.global_name,
      p.alias,
      p.roster_status,
      p.primary_position,
      p.secondary_position,
      COALESCE(p.riot_game_name, s.riot_game_name) AS riot_game_name,
      COALESCE(p.riot_tag, s.riot_tag) AS riot_tag,
      COALESCE(p.riot_region, s.riot_region, 'euw') AS riot_region,
      s.display_name AS standin_display_name,
      s.preferred_position AS standin_preferred_position
    FROM team_calendar_assignments a
    LEFT JOIN players p ON p.id = a.player_id
    LEFT JOIN standins s ON s.id = a.standin_id
    WHERE a.event_id = ?
    ORDER BY a.role_label ASC
  `).all(eventId);
}

function getRoleAssignment(eventId, roleLabel) {
  return db.prepare(`
    SELECT *
    FROM team_calendar_assignments
    WHERE event_id = ? AND role_label = ?
  `).get(eventId, roleLabel);
}

function buildOpggMultisearchUrl(summoners, region) {
  const normalizedRegion = (region || 'euw').toLowerCase();
  const query = encodeURIComponent(summoners.join(','));
  return `https://op.gg/lol/multisearch/${normalizedRegion}?summoners=${query}`;
}

function buildTeamOpggInfo(assignments) {
  const relevantAssignments = assignments.filter(item => STARTER_ROLES.includes(item.role_label));
  if (!relevantAssignments.length) {
    return { ok: false, message: 'Kein Lineup gesetzt.' };
  }

  const missingPlayers = [];
  const regions = new Set();
  const summoners = [];

  for (const item of relevantAssignments) {
    if (!item.player_id && !item.standin_id) {
      missingPlayers.push(`${item.role_label}: ${item.player_label} (nicht mit Profil verknüpft)`);
      continue;
    }

    if (!item.riot_game_name || !item.riot_tag) {
      missingPlayers.push(`${item.role_label}: ${item.player_label} (Riot-ID fehlt)`);
      continue;
    }

    regions.add(opggRegion(item.riot_region));
    summoners.push(`${item.riot_game_name}#${item.riot_tag}`);
  }

  if (missingPlayers.length) {
    return {
      ok: false,
      message: `Fehlende Riot-Daten: ${missingPlayers.join(' | ')}`
    };
  }

  if (regions.size > 1) {
    return {
      ok: false,
      message: `Mehrere Regionen im Lineup: ${[...regions].map(x => x.toUpperCase()).join(', ')}`
    };
  }

  return {
    ok: true,
    region: [...regions][0] || 'euw',
    summoners,
    url: buildOpggMultisearchUrl(summoners, [...regions][0] || 'euw')
  };
}

function buildDateTime(dateStr, timeStr) {
  return `${dateStr} ${timeStr}`;
}

function overlaps(startA, endA, startB, endB) {
  return startA < endB && startB < endA;
}

function getWeekdayIndexFromIsoDate(dateStr) {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

function getWeekdayBitFromIsoDate(dateStr) {
  const bits = [1, 2, 4, 8, 16, 32, 64];
  return bits[getWeekdayIndexFromIsoDate(dateStr)];
}

function startOfWeekMonday(dateStr) {
  const [year, month, day] = dateStr.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  const weekday = date.getUTCDay();
  const diffToMonday = weekday === 0 ? 6 : weekday - 1;
  date.setUTCDate(date.getUTCDate() - diffToMonday);

  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function daysBetweenIso(startDate, endDate) {
  const [sy, sm, sd] = startDate.split('-').map(Number);
  const [ey, em, ed] = endDate.split('-').map(Number);

  const start = Date.UTC(sy, sm - 1, sd);
  const end = Date.UTC(ey, em - 1, ed);

  return Math.floor((end - start) / (1000 * 60 * 60 * 24));
}

function weeksBetweenAnchorWeeks(anchorDate, targetDate) {
  const anchorWeekStart = startOfWeekMonday(anchorDate);
  const targetWeekStart = startOfWeekMonday(targetDate);
  return Math.floor(daysBetweenIso(anchorWeekStart, targetWeekStart) / 7);
}

function matchesRuleOnDate(rule, dateStr) {
  const recurrenceType = rule.recurrence_type ?? 'weekly';
  const anchorDate = rule.anchor_date ?? dateStr;

  if (dateStr < anchorDate) {
    return false;
  }

  switch (recurrenceType) {
    case 'weekly':
      return (rule.weekday_mask & getWeekdayBitFromIsoDate(dateStr)) !== 0;

    case 'biweekly': {
      if ((rule.weekday_mask & getWeekdayBitFromIsoDate(dateStr)) === 0) {
        return false;
      }

      const weekDiff = weeksBetweenAnchorWeeks(anchorDate, dateStr);
      return weekDiff >= 0 && weekDiff % 2 === 0;
    }

    case 'monthly':
      return Number(dateStr.slice(8, 10)) === Number(anchorDate.slice(8, 10));

    case 'yearly':
      return dateStr.slice(5, 10) === anchorDate.slice(5, 10);

    default:
      return false;
  }
}

function getRuleBlockedIntervalsForDate(rule, dateStr) {
  if (!matchesRuleOnDate(rule, dateStr)) {
    return [];
  }

  if (rule.suspended_from && dateStr >= rule.suspended_from && (!rule.suspended_until || dateStr <= rule.suspended_until)) {
    return [];
  }

  if (rule.rule_type === 'nicht_verfuegbar') {
    return [{ start_at: `${dateStr} 00:00`, end_at: `${dateStr} 23:59` }];
  }

  if (rule.rule_type === 'erst_ab' && rule.time_value) {
    return [{ start_at: `${dateStr} 00:00`, end_at: `${dateStr} ${rule.time_value}` }];
  }

  if (rule.rule_type === 'bis' && rule.time_value) {
    return [{ start_at: `${dateStr} ${rule.time_value}`, end_at: `${dateStr} 23:59` }];
  }

  return [];
}

function formatEntryRange(startAt, endAt) {
  const startDate = startAt.slice(0, 10);
  const endDate = endAt.slice(0, 10);
  const startTime = startAt.slice(11, 16);
  const endTime = endAt.slice(11, 16);
  const isAllDay = startTime === '00:00' && endTime === '23:59';

  if (isAllDay && startDate === endDate) {
    return `${formatDateDE(startDate)} (ganztägig)`;
  }

  if (isAllDay) {
    return `${formatDateDE(startDate)} → ${formatDateDE(endDate)} (ganztägig)`;
  }

  return `${formatDateTimeDE(startAt)} → ${formatDateTimeDE(endAt)}`;
}

function recurringDetail(rule) {
  if (rule.rule_type === 'nicht_verfuegbar') return 'ganztägig nicht verfügbar';
  if (rule.rule_type === 'erst_ab') return `bis ${rule.time_value} nicht verfügbar`;
  if (rule.rule_type === 'bis') return `ab ${rule.time_value} nicht verfügbar`;
  return rule.rule_type;
}

function getAvailabilitySnapshot(dateStr, startTime, durationMinutes) {
  const players = db.prepare(`
    SELECT id, discord_user_id, username, global_name, alias
    FROM players
    WHERE is_archived = 0
    ORDER BY COALESCE(alias, global_name, username) COLLATE NOCASE ASC
  `).all();

  const slotStartAt = buildDateTime(dateStr, startTime);
  const slotEndAt = buildDateTime(dateStr, addMinutesToTime(startTime, durationMinutes));

  const entries = db.prepare(`
    SELECT
      e.id,
      e.player_id,
      e.entry_type,
      e.start_at,
      e.end_at,
      e.reason,
      e.approval_status
    FROM availability_entries e
    WHERE e.end_at >= ?
      AND e.start_at <= ?
      AND e.approval_status <> 'rejected'
    ORDER BY e.start_at ASC
  `).all(slotStartAt, slotEndAt);

  const rules = db.prepare(`
    SELECT
      r.id,
      r.player_id,
      r.weekday_mask,
      r.rule_type,
      r.time_value,
      r.note,
      r.recurrence_type,
      r.anchor_date,
      r.active,
      r.suspended_from,
      r.suspended_until
    FROM availability_rules r
    WHERE r.active = 1
    ORDER BY r.player_id ASC, r.id ASC
  `).all();

  const available = [];
  const unavailable = [];

  for (const player of players) {
    const name = playerDisplay(player);
    const playerEntries = entries.filter(entry => entry.player_id === player.id);
    const playerRules = rules.filter(rule => rule.player_id === player.id);

    let reason = null;

    for (const entry of playerEntries) {
      if (!overlaps(slotStartAt, slotEndAt, entry.start_at, entry.end_at)) continue;
      const typeLabel = entry.entry_type === 'vacation' ? 'Urlaub' : 'Abwesenheit';
      const statusNote = entry.approval_status === 'pending_admin' ? ' • Status: wartet auf Freigabe' : '';
      reason = `[${typeLabel}] ${formatEntryRange(entry.start_at, entry.end_at)} • Grund: ${entry.reason ?? '-'}${statusNote}`;
      break;
    }

    if (!reason) {
      for (const rule of playerRules) {
        const intervals = getRuleBlockedIntervalsForDate(rule, dateStr);
        const blocked = intervals.some(interval => overlaps(slotStartAt, slotEndAt, interval.start_at, interval.end_at));
        if (!blocked) continue;
        reason = `[Regelmäßig] ${recurringDetail(rule)} • Start: ${formatDateDE(rule.anchor_date ?? dateStr)} • Notiz: ${rule.note ?? '-'}`;
        break;
      }
    }

    if (reason) unavailable.push({ name, reason });
    else available.push(name);
  }

  return {
    dateStr,
    startTime,
    durationMinutes,
    endTime: addMinutesToTime(startTime, durationMinutes),
    slotStartAt,
    slotEndAt,
    playersTotal: players.length,
    available,
    unavailable,
    allAvailable: unavailable.length === 0 && players.length > 0
  };
}


function getEventPlanningWindow(event) {
  const startAt = event.scheduled_start_at || event.window_start_at || event.start_at;
  const endAt = event.scheduled_end_at || event.window_end_at || event.end_at;
  if (!startAt || !endAt) return null;
  return { startAt, endAt, dateStr: startAt.slice(0, 10) };
}

function isPlayerAvailableForEvent(playerId, event) {
  const window = getEventPlanningWindow(event);
  if (!window) return true;

  const entries = db.prepare(`
    SELECT entry_type, start_at, end_at, approval_status
    FROM availability_entries
    WHERE player_id = ?
      AND end_at >= ?
      AND start_at <= ?
      AND approval_status <> 'rejected'
  `).all(playerId, window.startAt, window.endAt);

  if (entries.some(entry => overlaps(window.startAt, window.endAt, entry.start_at, entry.end_at))) {
    return false;
  }

  const rules = db.prepare(`
    SELECT *
    FROM availability_rules
    WHERE player_id = ? AND active = 1
  `).all(playerId);

  return !rules.some(rule =>
    getRuleBlockedIntervalsForDate(rule, window.dateStr)
      .some(interval => overlaps(window.startAt, window.endAt, interval.start_at, interval.end_at))
  );
}

function candidatePositionRank(candidate, roleLabel) {
  const primary = candidate.primary_position || candidate.preferred_position;
  const secondary = candidate.secondary_position;
  if (primary === roleLabel) return 0;
  if (secondary === roleLabel) return 1;
  if (primary === 'Fill' || secondary === 'Fill') return 2;
  return 9;
}

function getTeamLineupPlayers(event) {
  if (!event) return [];

  return db.prepare(`
    SELECT id, username, global_name, alias, roster_status,
           primary_position, secondary_position,
           riot_game_name, riot_tag, riot_region
    FROM players
    WHERE is_archived = 0
      AND team_id = ?
      AND COALESCE(roster_status, 'sub') IN ('main', 'sub')
    ORDER BY COALESCE(alias, global_name, username) COLLATE NOCASE ASC
  `).all(event.team_id)
    .map(player => ({
      ...player,
      is_available: isPlayerAvailableForEvent(player.id, event)
    }));
}

function getSuggestedPlayers(event) {
  return getTeamLineupPlayers(event)
    .filter(player => player.is_available);
}

function unavailableAssignmentWarning(candidate, event) {
  if (!candidate || candidate.candidate_type === 'standin') return '';
  if (isPlayerAvailableForEvent(candidate.id, event)) return '';
  return ' ⚠️ **Hinweis:** Dieser Spieler ist für den Termin als abwesend eingetragen.';
}

function saveLineupAssignment(eventId, roleLabel, candidate) {
  const now = new Date().toISOString();
  const isStandin = candidate.candidate_type === 'standin';
  db.prepare(`
    INSERT INTO team_calendar_assignments (
      event_id, role_label, player_label, assignee_type,
      player_id, standin_id, note, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
    ON CONFLICT(event_id, role_label)
    DO UPDATE SET
      player_label = excluded.player_label,
      assignee_type = excluded.assignee_type,
      player_id = excluded.player_id,
      standin_id = excluded.standin_id,
      updated_at = excluded.updated_at
  `).run(
    eventId,
    roleLabel,
    displayName(candidate),
    isStandin ? 'standin' : 'player',
    isStandin ? null : candidate.id,
    isStandin ? candidate.id : null,
    now,
    now
  );
}

function generateLineupSuggestion(eventId, { overwrite = false } = {}) {
  const event = getEventById(eventId);
  if (!event) return { assigned: 0, missing: STARTER_ROLES.slice() };

  if (overwrite) {
    db.prepare(`
      DELETE FROM team_calendar_assignments
      WHERE event_id = ? AND role_label IN ('Top', 'Jgl', 'Mid', 'ADC', 'Supp')
    `).run(eventId);
  }

  const existing = getAssignments(eventId);
  const byRole = new Map(existing.map(item => [item.role_label, item]));
  const usedPlayerIds = new Set(existing.map(item => item.player_id).filter(Boolean));
  const players = getSuggestedPlayers(event);
  let assigned = 0;
  const missing = [];

  for (const roleLabel of STARTER_ROLES) {
    if (byRole.has(roleLabel)) continue;

    const candidate = players
      .filter(player => !usedPlayerIds.has(player.id))
      .map(player => ({
        ...player,
        candidate_type: 'player',
        position_rank: candidatePositionRank(player, roleLabel),
        status_rank: normalizeRosterStatus(player.roster_status) === 'main' ? 0 : 1
      }))
      .filter(player => player.position_rank < 9)
      .sort((a, b) =>
        a.position_rank - b.position_rank ||
        a.status_rank - b.status_rank ||
        displayName(a).localeCompare(displayName(b), 'de')
      )[0];

    if (!candidate) {
      missing.push(roleLabel);
      continue;
    }

    saveLineupAssignment(eventId, roleLabel, candidate);
    usedPlayerIds.add(candidate.id);
    assigned++;
  }

  return { assigned, missing };
}

function buildStarterLineupSelectRows(eventId, messageId) {
  const event = getEventById(eventId);
  const assignments = getAssignments(eventId);
  const byRole = new Map(assignments.map(item => [item.role_label, item]));
  const usedPlayerIds = new Set(assignments.map(item => item.player_id).filter(Boolean));
  const candidates = getTeamLineupPlayers(event);

  return STARTER_ROLES.map(roleLabel => {
    const current = byRole.get(roleLabel);
    const options = [];

    if (current) {
      options.push({
        label: `${current.player_label} (aktuell)`.slice(0, 100),
        value: current.standin_id ? `standin:${current.standin_id}` : `player:${current.player_id}`,
        description: `${roleLabel} ist aktuell besetzt`.slice(0, 100),
        default: true
      });
    } else {
      options.push({
        label: 'Ersatz besorgen',
        value: '__replacement__',
        description: `Kein verfügbarer ${roleLabel}-Spieler gefunden`,
        default: true
      });
    }

    for (const player of candidates
      .filter(player => !usedPlayerIds.has(player.id) || player.id === current?.player_id)
      .sort((a, b) =>
        Number(!a.is_available) - Number(!b.is_available) ||
        candidatePositionRank(a, roleLabel) - candidatePositionRank(b, roleLabel) ||
        rosterSortRank(a.roster_status) - rosterSortRank(b.roster_status) ||
        displayName(a).localeCompare(displayName(b), 'de')
      )
      .slice(0, 23)) {
      const value = `player:${player.id}`;
      if (options.some(option => option.value === value)) continue;
      options.push(candidateOption({ ...player, candidate_type: 'player' }, roleLabel));
    }

    if (!options.some(option => option.value === '__replacement__')) {
      options.push({
        label: 'Ersatz besorgen',
        value: '__replacement__',
        description: 'Subs und Standins anzeigen'
      });
    }

    return new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`spieltermin:autoslot:${eventId}:${messageId}:${roleLabel}`)
        .setPlaceholder(`${roleLabel}: ${current?.player_label || 'Ersatz besorgen'}`)
        .addOptions(options.slice(0, 25))
    );
  });
}

function buildAutoLineupPayload(eventId, messageId, infoText = null) {
  const assignments = getAssignments(eventId);
  const missing = STARTER_ROLES.filter(role => !assignments.some(item => item.role_label === role));
  return {
    content: [
      infoText,
      `**Line-up-Vorschlag für #${eventId}**`,
      buildLineupText(assignments),
      missing.length
        ? `\n⚠️ **Ersatz besorgen:** ${missing.join(', ')}`
        : '\n✅ Alle Starter-Positionen sind besetzt.',
      '\nDu kannst jede Position direkt über das jeweilige Dropdown ändern.'
    ].filter(Boolean).join('\n'),
    components: buildStarterLineupSelectRows(eventId, messageId)
  };
}

function buildLineupConfirmationPayload(eventId, messageId, infoText = null) {
  const assignments = getAssignments(eventId);
  const missing = STARTER_ROLES.filter(role => !assignments.some(item => item.role_label === role));
  const complete = missing.length === 0;

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`spieltermin:lineupconfirm:${eventId}:${messageId}`)
      .setLabel('Aufstellung bestätigen')
      .setStyle(complete ? ButtonStyle.Success : ButtonStyle.Primary)
  );

  return {
    content: [
      infoText,
      complete
        ? '✅ Alle fünf Positionen sind besetzt. Bestätige die Aufstellung, damit die Termin- und Spielerkalenderkarten final aktualisiert werden.'
        : `⚠️ Aktuell noch offen: **${missing.join(', ')}**. Besetze die Positionen oben und klicke danach auf Bestätigen.`
    ].filter(Boolean).join('\n'),
    components: [row]
  };
}

function buildReplacementPayload(eventId, messageId, roleLabel) {
  const event = getEventById(eventId);
  const players = db.prepare(`
    SELECT id, username, global_name, alias, roster_status,
           primary_position, secondary_position,
           riot_game_name, riot_tag, riot_region
    FROM players
    WHERE is_archived = 0
      AND team_id = ?
      AND COALESCE(roster_status, 'sub') = 'sub'
    ORDER BY COALESCE(alias, global_name, username) COLLATE NOCASE ASC
  `).all(event.team_id).map(row => ({
    ...row,
    candidate_type: 'player',
    is_available: isPlayerAvailableForEvent(row.id, event)
  }));

  const standins = db.prepare(`
    SELECT id, display_name, riot_game_name, riot_tag, riot_region, preferred_position
    FROM standins
    WHERE is_active = 1
    ORDER BY display_name COLLATE NOCASE ASC
  `).all().map(row => ({ ...row, candidate_type: 'standin', roster_status: 'sub' }));

  const candidates = [...players, ...standins]
    .sort((a, b) =>
      candidatePositionRank(a, roleLabel) - candidatePositionRank(b, roleLabel) ||
      Number(a.is_available === false) - Number(b.is_available === false) ||
      (a.candidate_type === 'player' ? -1 : 1) ||
      displayName(a).localeCompare(displayName(b), 'de')
    )
    .slice(0, 24);

  const select = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`spieltermin:replacement:${eventId}:${messageId}:${roleLabel}`)
      .setPlaceholder(`${roleLabel}: Sub oder Standin auswählen`)
      .addOptions([
        ...candidates.map(candidate => candidateOption(candidate, roleLabel)),
        { label: 'Neuen Standin anlegen', value: '__new_standin__', description: 'Standin speichern und direkt einsetzen' }
      ].slice(0, 25))
  );

  const back = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`spieltermin:lineupback:${eventId}:${messageId}`)
      .setLabel('Zurück zum Vorschlag')
      .setStyle(ButtonStyle.Secondary)
  );

  return {
    content: `**Ersatz für ${roleLabel}**
Wähle einen Sub oder Standin. Ist die Person noch nicht vorhanden, nutze **Neuen Standin anlegen**.`,
    components: [select, back]
  };
}

function buildNewStandinModal(eventId, messageId, roleLabel) {
  const modal = new ModalBuilder()
    .setCustomId(`spieltermin:newstandin:${eventId}:${messageId}:${roleLabel}`)
    .setTitle(`Neuer Standin – ${roleLabel}`);

  const name = new TextInputBuilder().setCustomId('display_name').setLabel('Anzeigename').setStyle(TextInputStyle.Short).setRequired(true);
  const riot = new TextInputBuilder().setCustomId('riot_id').setLabel('Riot-ID (GameName#Tag)').setStyle(TextInputStyle.Short).setRequired(true);
  const region = new TextInputBuilder().setCustomId('riot_region').setLabel('OP.GG-Region, z. B. EUW').setStyle(TextInputStyle.Short).setRequired(true).setValue('EUW');
  const note = new TextInputBuilder().setCustomId('note').setLabel('Notiz (optional)').setStyle(TextInputStyle.Short).setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(name),
    new ActionRowBuilder().addComponents(riot),
    new ActionRowBuilder().addComponents(region),
    new ActionRowBuilder().addComponents(note)
  );
  return modal;
}

function buildCardToggleRow(event, collapsed) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`spieltermin:${collapsed ? 'expand' : 'collapse'}:${event.id}`)
      .setLabel(collapsed ? 'Ausklappen' : 'Einklappen')
      .setEmoji(collapsed ? '🔽' : '🔼')
      .setStyle(ButtonStyle.Secondary)
  );
}

function buildEventActionRows(event, collapsed = false) {
  if (collapsed) {
    return [buildCardToggleRow(event, true)];
  }

  const publishEnabled = Number(event.show_in_player_calendar) === 1;

  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`spieltermin:status:${event.id}`)
        .setLabel('Status')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:type:${event.id}`)
        .setLabel('Typ')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:fixedtime:${event.id}`)
        .setLabel('Fixe Zeit')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:meeting:${event.id}`)
        .setLabel('Treffpunkt')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:lineup:${event.id}`)
        .setLabel('Aufstellung')
        .setStyle(ButtonStyle.Primary)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`spieltermin:opponent:${event.id}`)
        .setLabel('Gegner')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:enemyopgg:${event.id}`)
        .setLabel('Gegner OPGG')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:teamopgg:${event.id}`)
        .setLabel('Team OPGG')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`spieltermin:note:${event.id}`)
        .setLabel('Hinweis')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`spieltermin:playervisibility:${event.id}`)
        .setLabel(publishEnabled ? 'Spielerkalender: AN' : 'Spielerkalender: AUS')
        .setStyle(publishEnabled ? ButtonStyle.Success : ButtonStyle.Secondary)
    ),
    buildCardToggleRow(event, false)
  ];
}

function buildStatusSelectRow(eventId, messageId, currentStatus) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`spieltermin:statusselect:${eventId}:${messageId}`)
      .setPlaceholder('Neuen Status auswählen')
      .addOptions(
        {
          label: 'Pending',
          value: 'pending',
          description: 'Terminoption ist offen',
          default: currentStatus === 'pending'
        },
        {
          label: 'Fixed',
          value: 'fixed',
          description: 'Termin ist bestätigt',
          default: currentStatus === 'fixed'
        },
        {
          label: 'Cancelled',
          value: 'cancelled',
          description: 'Termin wurde abgesagt',
          default: currentStatus === 'cancelled'
        }
      )
  );
}

function buildTypeSelectRow(eventId, messageId, currentType) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`spieltermin:typeselect:${eventId}:${messageId}`)
      .setPlaceholder('Neuen Typ auswählen')
      .addOptions(
        {
          label: 'Offen',
          value: 'open',
          description: 'Terminart ist noch offen',
          default: (currentType || 'open') === 'open'
        },
        {
          label: 'Flex',
          value: 'flex',
          description: 'Gemeinsame Flex-Queue',
          default: currentType === 'flex'
        },
        {
          label: 'Scrim',
          value: 'scrim',
          description: 'Scrim / Trainingsspiel',
          default: currentType === 'scrim'
        },
        {
          label: 'Prime League',
          value: 'primeleague',
          description: 'Prime-League-Spiel',
          default: currentType === 'primeleague'
        },
        {
          label: 'Sonstiges',
          value: 'other',
          description: 'Anderer Termin',
          default: currentType === 'other'
        }
      )
  );
}



function buildRoleSelectRow(eventId, messageId) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`spieltermin:lineuprole:${eventId}:${messageId}`)
      .setPlaceholder('Position auswählen')
      .addOptions(ROLE_ORDER.map(role => ({
        label: role,
        value: role,
        description: role.startsWith('Sub') ? 'Ersatzspieler-Slot' : `Starter-Position ${role}`
      })))
  );
}

function getLineupCandidates(roleLabel, event) {
  const players = db.prepare(`
    SELECT
      id,
      username,
      global_name,
      alias,
      roster_status,
      primary_position,
      secondary_position,
      riot_game_name,
      riot_tag,
      riot_region
    FROM players
    WHERE is_archived = 0
      AND team_id = ?
      AND COALESCE(roster_status, 'sub') <> 'inactive'
    ORDER BY
      CASE COALESCE(roster_status, 'sub')
        WHEN 'main' THEN 0
        WHEN 'sub' THEN 1
        WHEN 'coach' THEN 2
        WHEN 'admin' THEN 3
        ELSE 9
      END ASC,
      COALESCE(alias, global_name, username) COLLATE NOCASE ASC
  `).all(event?.team_id).map(player => ({
    ...player,
    candidate_type: 'player',
    is_available: isPlayerAvailableForEvent(player.id, event)
  }));

  const standins = db.prepare(`
    SELECT
      id,
      display_name,
      riot_game_name,
      riot_tag,
      riot_region,
      preferred_position
    FROM standins
    WHERE is_active = 1
    ORDER BY COALESCE(preferred_position, 'ZZZ') ASC, display_name COLLATE NOCASE ASC
  `).all().map(standin => ({ ...standin, candidate_type: 'standin', roster_status: 'sub' }));

  return [...players, ...standins]
    .sort((a, b) => {
      const aMatch = positionMatchesRole(a, roleLabel) ? 0 : 1;
      const bMatch = positionMatchesRole(b, roleLabel) ? 0 : 1;
      if (aMatch !== bMatch) return aMatch - bMatch;
      const availabilityDiff = Number(a.is_available === false) - Number(b.is_available === false);
      if (availabilityDiff !== 0) return availabilityDiff;
      if (a.candidate_type !== b.candidate_type) return a.candidate_type === 'player' ? -1 : 1;
      const rankDiff = rosterSortRank(a.roster_status) - rosterSortRank(b.roster_status);
      if (rankDiff !== 0) return rankDiff;
      return displayName(a).localeCompare(displayName(b), 'de');
    });
}

function candidateOption(candidate, roleLabel) {
  const isStandin = candidate.candidate_type === 'standin';
  const isUnavailable = !isStandin && candidate.is_available === false;
  const prefix = isStandin ? '[Standin]' : `[${rosterStatusLabel(candidate.roster_status)}]`;
  const pos = candidate.primary_position || candidate.preferred_position || '-';
  const secondary = candidate.secondary_position ? `/${candidate.secondary_position}` : '';
  const riot = candidate.riot_game_name && candidate.riot_tag ? `${candidate.riot_game_name}#${candidate.riot_tag}` : 'Riot-ID fehlt';
  const matchHint = positionMatchesRole(candidate, roleLabel) ? 'passt zur Position' : 'andere Position';
  const availabilityHint = isUnavailable ? '⚠️ abwesend' : (!isStandin && candidate.is_available === true ? 'verfügbar' : null);

  return {
    label: `${isUnavailable ? '⚠️ ' : ''}${prefix} ${displayName(candidate)}`.slice(0, 100),
    value: `${isStandin ? 'standin' : 'player'}:${candidate.id}`,
    description: [availabilityHint, `${pos}${secondary}`, riot, matchHint].filter(Boolean).join(' • ').slice(0, 100)
  };
}

function buildPlayerSelectRow(eventId, messageId, roleLabel) {
  const event = getEventById(eventId);
  const candidates = getLineupCandidates(roleLabel, event);
  const options = [
    {
      label: `${roleLabel} leeren`,
      value: '__clear__',
      description: 'Entfernt die aktuelle Besetzung dieser Position'
    },
    ...candidates.slice(0, 24).map(candidate => candidateOption(candidate, roleLabel))
  ];

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`spieltermin:lineupplayer:${eventId}:${messageId}:${roleLabel}`)
      .setPlaceholder(`${roleLabel}: Spieler oder Standin auswählen`)
      .addOptions(options)
  );
}

function buildLineupManagerPayload(eventId, messageId, infoText = null) {
  const assignments = getAssignments(eventId);
  const text = [
    infoText,
    `**Aufstellung für #${eventId}**`,
    buildLineupText(assignments),
    '',
    'Wähle zuerst eine Position und danach den Spieler oder Standin.'
  ].filter(Boolean).join('\n');

  return {
    content: text,
    components: [buildRoleSelectRow(eventId, messageId)]
  };
}


function buildLineupModalValue(eventId) {
  const assignments = getAssignments(eventId);
  const byRole = new Map(assignments.map(item => [item.role_label, item.player_label]));

  return ROLE_ORDER
    .map(role => `${role}: ${byRole.get(role) || '-'}`)
    .join('\n');
}

function parseLineupModalText(raw) {
  const lines = String(raw || '')
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);

  const recognized = new Map();
  const rolePattern = /^(Top|Jgl|Mid|ADC|Supp|Sub1|Sub2)\s*:\s*(.*)$/i;

  for (const line of lines) {
    const match = line.match(rolePattern);
    if (!match) continue;

    const normalizedRole = ROLE_ORDER.find(role => role.toLowerCase() === match[1].toLowerCase());
    if (!normalizedRole) continue;

    recognized.set(normalizedRole, (match[2] || '').trim());
  }

  return recognized;
}

async function applyLineupChanges(eventId, roleMap) {
  const event = getEventById(eventId);
  const teamId = event?.team_id ?? null;
  const now = new Date().toISOString();
  let changed = 0;

  for (const [roleLabel, rawValue] of roleMap.entries()) {
    const trimmed = String(rawValue || '').trim();

    if (trimmed === '' || trimmed === '-' || trimmed === '—') {
      db.prepare(`
        DELETE FROM team_calendar_assignments
        WHERE event_id = ?
          AND role_label = ?
      `).run(eventId, roleLabel);
      changed++;
      continue;
    }

    const matchedPlayer = findPlayerByLabel(trimmed, teamId);
    const matchedStandin = matchedPlayer ? null : findStandinByLabel(trimmed);
    const assigneeType = matchedPlayer ? 'player' : matchedStandin ? 'standin' : 'manual';
    const playerLabel = matchedPlayer
      ? playerDisplay(matchedPlayer)
      : matchedStandin
        ? matchedStandin.display_name
        : trimmed;

    db.prepare(`
      INSERT INTO team_calendar_assignments (
        event_id,
        role_label,
        player_label,
        assignee_type,
        player_id,
        standin_id,
        note,
        created_at,
        updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
      ON CONFLICT(event_id, role_label)
      DO UPDATE SET
        player_label = excluded.player_label,
        assignee_type = excluded.assignee_type,
        player_id = excluded.player_id,
        standin_id = excluded.standin_id,
        updated_at = excluded.updated_at
    `).run(
      eventId,
      roleLabel,
      playerLabel,
      assigneeType,
      matchedPlayer?.id ?? null,
      matchedStandin?.id ?? null,
      now,
      now
    );
    changed++;
  }

  return changed;
}

function playerCalendarTypeLabel(event) {
  switch (event.event_type) {
    case 'primeleague':
      return 'PRM';
    case 'scrim':
      return 'Scrims';
    case 'open':
      return 'Offen';
    case 'flex':
      return 'Flex';
    case 'other':
      return event.title || 'Sonstiges';
    default:
      return eventTypeLabel(event.event_type);
  }
}

function buildPlayerCalendarPayload(eventId) {
  const event = getEventById(eventId);
  if (!event) return null;

  const assignments = getAssignments(eventId);

  const embed = new EmbedBuilder()
    .setColor(statusColor(event.status))
    .setTitle(buildPlayerCalendarTitle(event))
    .setDescription(buildPlayerCalendarDescription(event, assignments))
    .setTimestamp(new Date(event.updated_at || event.created_at || Date.now()));

  return {
    embeds: [embed],
    components: []
  };
}

async function deleteStoredAdminCard(client, eventId) {
  const event = getEventById(eventId);
  if (!event?.admin_channel_id || !event?.admin_message_id) {
    return false;
  }

  try {
    const channel = await client.channels.fetch(event.admin_channel_id);
    if (channel && channel.isTextBased()) {
      try {
        const message = await channel.messages.fetch(event.admin_message_id);
        if (message) {
          await message.delete().catch(() => null);
        }
      } catch (_) {
        // Nachricht existiert evtl. schon nicht mehr
      }
    }
  } catch (_) {
    // Kanal evtl. nicht mehr erreichbar
  }

  return true;
}

async function deleteStoredPlayerCard(client, eventId) {
  const event = getEventById(eventId);
  if (!event?.player_channel_id || !event?.player_message_id) {
    return false;
  }

  try {
    const channel = await client.channels.fetch(event.player_channel_id);
    if (channel && channel.isTextBased()) {
      try {
        const message = await channel.messages.fetch(event.player_message_id);
        if (message) {
          await message.delete().catch(() => null);
        }
      } catch (_) {
        // Nachricht existiert evtl. schon nicht mehr
      }
    }
  } catch (_) {
    // Kanal evtl. nicht mehr erreichbar
  }

  db.prepare(`
    UPDATE team_calendar_events
    SET player_channel_id = NULL,
        player_message_id = NULL,
        updated_at = ?
    WHERE id = ?
  `).run(new Date().toISOString(), eventId);

  return true;
}

async function syncPlayerCalendarCard(client, eventId) {
  const event = getEventById(eventId);
  if (!event) return false;

  const shouldShow = Number(event.show_in_player_calendar) === 1;

  if (!shouldShow) {
    await deleteStoredPlayerCard(client, eventId);
    return false;
  }

  const playerChannelId = getTeamById(event.team_id)?.player_calendar_channel_id || process.env.PLAYER_CALENDAR_CHANNEL_ID;
  if (!playerChannelId) return false;

  try {
    const channel = await client.channels.fetch(playerChannelId);
    if (!channel || !channel.isTextBased()) return false;

    const payload = buildPlayerCalendarPayload(eventId);
    if (!payload) return false;

    if (event.player_message_id && event.player_channel_id === channel.id) {
      try {
        const existingMessage = await channel.messages.fetch(event.player_message_id);
        if (existingMessage) {
          await existingMessage.edit(payload);
          return true;
        }
      } catch (_) {
        // fällt unten auf Neu-Senden zurück
      }
    }

    const sentMessage = await channel.send(payload);

    db.prepare(`
      UPDATE team_calendar_events
      SET player_channel_id = ?,
          player_message_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(channel.id, sentMessage.id, new Date().toISOString(), eventId);

    return true;
  } catch (error) {
    console.error(`[Spieltermin] Konnte Player-Karte für Event #${eventId} nicht synchronisieren:`, error);
    return false;
  }
}

function buildEventCardPayload(eventId) {
  const event = getEventById(eventId);
  if (!event) return null;

  const assignments = getAssignments(eventId);
  const collapsed = Number(event.admin_card_collapsed) === 1;
  const exactTime =
    event.scheduled_start_at && event.scheduled_end_at
      ? `${formatDateTimeDE(event.scheduled_start_at)} → ${formatDateTimeDE(event.scheduled_end_at)}`
      : '-';

  if (collapsed) {
    const descriptionLines = [];

    if (event.scheduled_start_at) {
      descriptionLines.push(`🕒 **Uhrzeit:** ${formatTimeOnlyLabel(event.scheduled_start_at)}`);
    }

    descriptionLines.push(
      `🎮 **Art:** ${eventTypeLabel(event.event_type)}`,
      `👥 **Verfügbar:** ${buildAvailablePlayersForCard(event)}`,
      `🔎 **Gesucht:** ${buildMissingStarterRolesText(assignments)}`,
      `${statusEmoji(event.status)} **Status:** ${statusLabel(event.status)}`
    );

    const embed = new EmbedBuilder()
      .setColor(statusColor(event.status))
      .setTitle(`📅 ${formatDateLongDE(event.option_date)}`)
      .setDescription(descriptionLines.join('\n'));

    return {
      embeds: [embed],
      components: buildEventActionRows(event, true)
    };
  }

  const teamOpgg = buildTeamOpggInfo(assignments);
  const teamOpggField = teamOpgg.ok
    ? `[OP.GG öffnen](${teamOpgg.url})`
    : teamOpgg.message;

  const embed = new EmbedBuilder()
    .setColor(statusColor(event.status))
    .setTitle(`${statusEmoji(event.status)} ${event.title}`)
    .setDescription(`Kalender-ID: **#${event.id}**`)
    .addFields(
      {
        name: 'Status',
        value: statusLabel(event.status),
        inline: true
      },
      {
        name: 'Typ',
        value: eventTypeLabel(event.event_type),
        inline: true
      },
      {
        name: 'Gegner',
        value: truncateField(event.opponent_name ?? '-'),
        inline: true
      },
      {
        name: 'Tag',
        value: formatDateLongDE(event.option_date),
        inline: false
      },
      {
        name: 'Zeitfenster',
        value: `${formatDateTimeDE(event.window_start_at)} → ${formatDateTimeDE(event.window_end_at)}`,
        inline: false
      },
      {
        name: 'Fixe Zeit',
        value: exactTime,
        inline: false
      },
      {
        name: 'Treffpunkt',
        value: truncateField(buildMeetingFieldValue(event)),
        inline: false
      },
      {
        name: 'Verfügbare Spieler',
        value: truncateField(event.available_players_text ?? '-'),
        inline: false
      },
      {
        name: 'Lineup',
        value: truncateField(buildLineupText(assignments)),
        inline: false
      },
      {
        name: 'Gegner OPGG',
        value: truncateField(event.opgg_url ?? '-'),
        inline: false
      },
      {
        name: 'Team OPGG',
        value: truncateField(teamOpggField),
        inline: false
      },
      {
        name: 'Hinweis',
        value: truncateField(event.note ?? '-'),
        inline: false
      }
    )
    .setFooter({
      text: 'Standard-Treffpunkt: Scrim 15 Min vorher / Prime League 30 Min vorher'
    })
    .setTimestamp(new Date(event.updated_at || event.created_at || Date.now()));

  return {
    embeds: [embed],
    components: buildEventActionRows(event, false)
  };
}

async function refreshSpecificCard(channel, messageId, eventId) {
  const payload = buildEventCardPayload(eventId);
  if (!payload) return false;

  try {
    const message = await channel.messages.fetch(messageId);
    if (!message) return false;
    await message.edit(payload);

    await syncPlayerCalendarCard(channel.client, eventId);

    return true;
  } catch (error) {
    console.error(`[Spieltermin] Konnte Karte ${messageId} für Event #${eventId} nicht aktualisieren:`, error);
    return false;
  }
}

async function refreshStoredPlayerCard(client, eventId) {
  const playerChannelId = getTeamById(event.team_id)?.player_calendar_channel_id || process.env.PLAYER_CALENDAR_CHANNEL_ID;
  if (!playerChannelId) return false;

  const event = getEventById(eventId);
  if (!event) return false;

  try {
    const channel = await client.channels.fetch(playerChannelId);
    if (!channel || !channel.isTextBased()) return false;

    const payload = buildPlayerCalendarPayload(eventId);
    if (!payload) return false;

    if (!event.player_message_id || event.player_channel_id !== channel.id) {
      const message = await upsertPlayerCardMessage(channel, eventId);
      return !!message;
    }

    const message = await channel.messages.fetch(event.player_message_id);
    if (!message) return false;

    await message.edit(payload);
    return true;
  } catch (error) {
    console.error(`[Spieltermin] Konnte Player-Karte für Event #${eventId} nicht aktualisieren:`, error);
    return false;
  }
}

async function refreshStoredEventCard(client, eventId) {
  let refreshed = false;
  const event = getEventById(eventId);

  if (event?.admin_channel_id && event?.admin_message_id) {
    try {
      const adminChannel = await client.channels.fetch(event.admin_channel_id);
      if (adminChannel && adminChannel.isTextBased()) {
        const payload = buildEventCardPayload(eventId);
        if (payload) {
          const message = await adminChannel.messages.fetch(event.admin_message_id);
          if (message) {
            await message.edit(payload);
            refreshed = true;
          }
        }
      }
    } catch (error) {
      console.error(`[Spieltermin] Konnte gespeicherte Admin-Karte für Event #${eventId} nicht laden:`, error);
    }
  }

  const mirrored = await refreshStoredPlayerCard(client, eventId);
  return refreshed || mirrored;
}

async function upsertPlayerCardMessage(channel, eventId) {
  const event = getEventById(eventId);
  if (!event) return null;

  const payload = buildPlayerCalendarPayload(eventId);
  if (!payload) return null;

  if (event.player_message_id) {
    try {
      const existingMessage = await channel.messages.fetch(event.player_message_id);
      if (existingMessage) {
        await existingMessage.edit(payload);

        if (event.player_channel_id !== channel.id) {
          db.prepare(`
            UPDATE team_calendar_events
            SET player_channel_id = ?, updated_at = ?
            WHERE id = ?
          `).run(channel.id, new Date().toISOString(), eventId);
        }

        return existingMessage;
      }
    } catch (error) {
      console.warn(`[Spieltermin] Gespeicherte Player-Karte für Event #${eventId} nicht gefunden, sende neu.`);
    }
  }

  const sentMessage = await channel.send(payload);

  db.prepare(`
    UPDATE team_calendar_events
    SET player_channel_id = ?,
        player_message_id = ?,
        updated_at = ?
    WHERE id = ?
  `).run(channel.id, sentMessage.id, new Date().toISOString(), eventId);

  return sentMessage;
}

async function upsertAdminCardMessage(channel, eventId) {
  const event = getEventById(eventId);
  if (!event) return null;

  const payload = buildEventCardPayload(eventId);
  if (!payload) return null;

  let adminMessage = null;

  if (event.admin_message_id) {
    try {
      const existingMessage = await channel.messages.fetch(event.admin_message_id);
      if (existingMessage) {
        await existingMessage.edit(payload);

        if (event.admin_channel_id !== channel.id) {
          db.prepare(`
            UPDATE team_calendar_events
            SET admin_channel_id = ?, updated_at = ?
            WHERE id = ?
          `).run(channel.id, new Date().toISOString(), eventId);
        }

        adminMessage = existingMessage;
      }
    } catch (error) {
      console.warn(`[Spieltermin] Gespeicherte Karten-Nachricht für Event #${eventId} nicht gefunden, sende neu.`);
    }
  }

  if (!adminMessage) {
    adminMessage = await channel.send(payload);

    db.prepare(`
      UPDATE team_calendar_events
      SET admin_channel_id = ?,
          admin_message_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(channel.id, adminMessage.id, new Date().toISOString(), eventId);
  }

  await syncPlayerCalendarCard(channel.client, eventId);
  return adminMessage;
}

async function refreshAllStoredAdminCards(client) {
  const events = db.prepare(`
    SELECT id, admin_channel_id, admin_message_id
    FROM team_calendar_events
    WHERE admin_channel_id IS NOT NULL
      AND admin_message_id IS NOT NULL
    ORDER BY option_date ASC, id ASC
  `).all();

  let refreshed = 0;

  for (const event of events) {
    try {
      const channel = await client.channels.fetch(event.admin_channel_id);
      if (!channel || !channel.isTextBased()) continue;

      const message = await channel.messages.fetch(event.admin_message_id).catch(() => null);
      if (!message) continue;

      const payload = buildEventCardPayload(event.id);
      if (!payload) continue;

      await message.edit(payload);
      refreshed++;
    } catch (error) {
      console.warn(`[Spieltermin] Admin-Karte #${event.id} konnte beim Start nicht aktualisiert werden:`, error.message);
    }
  }

  return refreshed;
}

function ensureAdminPermission(interaction) {
  return isAdminInteraction(interaction);
}

function parsePlannerCustomId(customId) {
  const parts = customId.split(':');
  if (parts[0] !== 'spieltermin') return null;
  return parts;
}

async function handleButtonInteraction(interaction, parts) {
  if (!ensureAdminPermission(interaction)) {
    return interaction.reply({
      content: 'Dafür fehlen dir die Rechte.',
      flags: MessageFlags.Ephemeral
    });
  }

  const action = parts[1];
  const eventId = Number(parts[2]);
  const messageId = interaction.message?.id;
  const event = getEventById(eventId);

  if (!event) {
    return interaction.reply({
      content: 'Dieser Kalendereintrag existiert nicht mehr.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'collapse' || action === 'expand') {
    const collapsed = action === 'collapse' ? 1 : 0;

    db.prepare(`
      UPDATE team_calendar_events
      SET admin_card_collapsed = ?
      WHERE id = ?
    `).run(collapsed, eventId);

    const payload = buildEventCardPayload(eventId);
    if (!payload) {
      return interaction.reply({
        content: 'Die Terminkarte konnte nicht aktualisiert werden.',
        flags: MessageFlags.Ephemeral
      });
    }

    return interaction.update(payload);
  }

  if (action === 'status') {
    return interaction.showModal(buildStatusModal(eventId, messageId, event.status));
  }

  if (action === 'type') {
    return interaction.showModal(buildTypeModal(eventId, messageId, event.event_type));
  }

  if (action === 'fixedtime') {
    const modal = new ModalBuilder()
      .setCustomId(`spieltermin:fixedtimemodal:${eventId}:${messageId}`)
      .setTitle(`Fixe Zeit – #${eventId}`);

    const startInput = new TextInputBuilder()
      .setCustomId('scheduled_start_time')
      .setLabel('Startzeit (HH:MM)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('z. B. 19:00 oder - zum Löschen');

    const endInput = new TextInputBuilder()
      .setCustomId('scheduled_end_time')
      .setLabel('Endzeit (HH:MM, optional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('leer = aktuelle Dauer beibehalten');

    if (event.scheduled_start_at) {
      startInput.setValue(event.scheduled_start_at.slice(11, 16));
    }

    if (event.scheduled_end_at) {
      endInput.setValue(event.scheduled_end_at.slice(11, 16));
    }

    modal.addComponents(
      new ActionRowBuilder().addComponents(startInput),
      new ActionRowBuilder().addComponents(endInput)
    );

    return interaction.showModal(modal);
  }

  if (action === 'meeting') {
    if (!event.scheduled_start_at) {
      return interaction.reply({
        content: 'Setze zuerst eine fixe Zeit.',
        flags: MessageFlags.Ephemeral
      });
    }

    const modal = new ModalBuilder()
      .setCustomId(`spieltermin:meetingmodal:${eventId}:${messageId}`)
      .setTitle(`Treffpunkt – #${eventId}`);

    const scrimInput = new TextInputBuilder()
      .setCustomId('meeting_scrim_time')
      .setLabel('Treffpunkt Scrim (HH:MM)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('leer oder - = Standard 15 Min vorher');

    const primeInput = new TextInputBuilder()
      .setCustomId('meeting_prime_time')
      .setLabel('Treffpunkt Prime League (HH:MM)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('leer oder - = Standard 30 Min vorher');

    const currentScrim = getEffectiveMeetingAt(event, 'scrim');
    const currentPrime = getEffectiveMeetingAt(event, 'primeleague');

    if (currentScrim) {
      scrimInput.setValue(currentScrim.slice(11, 16));
    }

    if (currentPrime) {
      primeInput.setValue(currentPrime.slice(11, 16));
    }

    modal.addComponents(
      new ActionRowBuilder().addComponents(scrimInput),
      new ActionRowBuilder().addComponents(primeInput)
    );

    return interaction.showModal(modal);
  }
  if (action === 'lineup') {
    const starterAssignments = getAssignments(eventId).filter(item => STARTER_ROLES.includes(item.role_label));
    if (starterAssignments.length === 0) generateLineupSuggestion(eventId);

    await interaction.reply({ ...buildAutoLineupPayload(eventId, messageId), flags: MessageFlags.Ephemeral });
    await interaction.followUp({ ...buildLineupConfirmationPayload(eventId, messageId), flags: MessageFlags.Ephemeral });
    return;
  }

  if (action === 'lineupconfirm') {
    const sourceMessageId = parts[3] || messageId;
    const assignments = getAssignments(eventId).filter(item => STARTER_ROLES.includes(item.role_label));
    const missing = STARTER_ROLES.filter(role => !assignments.some(item => item.role_label === role));

    if (missing.length > 0) {
      return interaction.update(buildLineupConfirmationPayload(
        eventId,
        sourceMessageId,
        `Die Aufstellung kann noch nicht bestätigt werden. Offen: **${missing.join(', ')}**.`
      ));
    }

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE team_calendar_events
      SET updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(interaction.user.id, now, eventId);

    const refreshed = await refreshSpecificCard(interaction.channel, sourceMessageId, eventId);
    const teamOpgg = buildTeamOpggInfo(assignments);

    return interaction.update({
      content: [
        `✅ **Aufstellung für #${eventId} bestätigt.**`,
        refreshed
          ? 'Die Termin- und gegebenenfalls Spielerkalenderkarte wurden aktualisiert.'
          : 'Die Aufstellung wurde gespeichert, die ursprüngliche Terminkarte konnte aber nicht aktualisiert werden.',
        teamOpgg.ok ? `**Team OP.GG:** ${teamOpgg.url}` : null
      ].filter(Boolean).join('\n'),
      components: []
    });
  }

  if (action === 'lineupback') {
    const sourceMessageId = parts[3] || messageId;
    return interaction.update(buildAutoLineupPayload(eventId, sourceMessageId));
  }

  if (action === 'opponent') {
    const modal = new ModalBuilder()
      .setCustomId(`spieltermin:opponentmodal:${eventId}:${messageId}`)
      .setTitle(`Gegner – #${eventId}`);

    const input = new TextInputBuilder()
      .setCustomId('opponent_name')
      .setLabel('Gegnername')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('Leer lassen oder - eingeben, um zu löschen');

    if (event.opponent_name) input.setValue(event.opponent_name);

    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (action === 'enemyopgg') {
    const modal = new ModalBuilder()
      .setCustomId(`spieltermin:enemyopggmodal:${eventId}:${messageId}`)
      .setTitle(`Gegner OPGG – #${eventId}`);

    const input = new TextInputBuilder()
      .setCustomId('opgg_url')
      .setLabel('OPGG-Link des Gegners')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setPlaceholder('Leer lassen oder - eingeben, um zu löschen');

    if (event.opgg_url) input.setValue(event.opgg_url);

    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (action === 'note') {
    const modal = new ModalBuilder()
      .setCustomId(`spieltermin:notemodal:${eventId}:${messageId}`)
      .setTitle(`Hinweis – #${eventId}`);

    const input = new TextInputBuilder()
      .setCustomId('note_text')
      .setLabel('Hinweistext')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setPlaceholder('Leer lassen oder - eingeben, um zu löschen');

    if (event.note) input.setValue(event.note);

    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (action === 'playervisibility') {
    const nextValue = Number(event.show_in_player_calendar) === 1 ? 0 : 1;

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    db.prepare(`
      UPDATE team_calendar_events
      SET show_in_player_calendar = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextValue, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    const playerCalendarChannelConfigured = Boolean(getTeamById(event.team_id)?.player_calendar_channel_id || process.env.PLAYER_CALENDAR_CHANNEL_ID);
    const playerCalendarHint = nextValue === 1 && !playerCalendarChannelConfigured
      ? '\n⚠️ Für dieses Team ist kein Spielerkalender-Kanal eingerichtet. Die Admin-Karte wurde aktualisiert, aber es konnte keine Spielerkarte gepostet werden.'
      : '';

    return interaction.editReply({
      content: nextValue === 1
        ? `Spielerkalender für **#${eventId}** wurde auf **AN** gestellt.${playerCalendarHint}`
        : `Spielerkalender für **#${eventId}** wurde auf **AUS** gestellt. Die gespiegelte Spielerkarte wurde entfernt, falls sie existierte.`
    });
  }

  if (action === 'teamopgg') {
    const teamOpgg = buildTeamOpggInfo(getAssignments(eventId));

    return interaction.reply({
      content: teamOpgg.ok
        ? `**Team OPGG für #${eventId}:**\n${teamOpgg.url}`
        : `Kein Team-OPGG möglich: ${teamOpgg.message}`,
      flags: MessageFlags.Ephemeral
    });
  }
}

async function handleStringSelectInteraction(interaction, parts) {
  if (!ensureAdminPermission(interaction)) {
    return interaction.reply({
      content: 'Dafür fehlen dir die Rechte.',
      flags: MessageFlags.Ephemeral
    });
  }

  const action = parts[1];
  const eventId = Number(parts[2]);
  const messageId = parts[3];
  const event = getEventById(eventId);

  if (!event) {
    return interaction.update({
      content: 'Dieser Kalendereintrag existiert nicht mehr.',
      components: []
    });
  }

  if (action === 'statusselect') {
    const nextStatus = interaction.values[0];

    if (!STATUS_VALUES.includes(nextStatus)) {
      return interaction.update({
        content: 'Ungültiger Status.',
        components: []
      });
    }

    db.prepare(`
      UPDATE team_calendar_events
      SET status = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextStatus, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.update({
      content: `Status für **#${eventId}** wurde auf **${statusLabel(nextStatus)}** gesetzt.`,
      components: []
    });
  }

  if (action === 'typeselect') {
    const nextType = interaction.values[0];

    if (!EVENT_TYPE_VALUES.includes(nextType)) {
      return interaction.update({
        content: 'Ungültiger Typ.',
        components: []
      });
    }

    db.prepare(`
      UPDATE team_calendar_events
      SET event_type = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextType, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.update({
      content: `Typ für **#${eventId}** wurde auf **${eventTypeLabel(nextType)}** gesetzt.`,
      components: []
    });
  }

  if (action === 'autoslot') {
    const roleLabel = parts[4];
    const selectedValue = interaction.values[0];

    if (selectedValue === '__replacement__') {
      db.prepare(`
        DELETE FROM team_calendar_assignments
        WHERE event_id = ? AND role_label = ?
      `).run(eventId, roleLabel);

      await refreshSpecificCard(interaction.channel, messageId, eventId);

      return interaction.update(buildReplacementPayload(eventId, messageId, roleLabel));
    }

    const [selectedType, selectedIdRaw] = String(selectedValue).split(':');
    const selectedId = Number(selectedIdRaw);
    const candidate = selectedType === 'standin'
      ? db.prepare(`SELECT *, 'standin' AS candidate_type FROM standins WHERE id = ? AND is_active = 1`).get(selectedId)
      : db.prepare(`SELECT *, 'player' AS candidate_type FROM players WHERE id = ? AND is_archived = 0 AND team_id = ?`).get(selectedId, event.team_id);

    if (!candidate) {
      return interaction.update({ content: 'Die ausgewählte Person wurde nicht gefunden.', components: [] });
    }

    db.prepare(`DELETE FROM team_calendar_assignments WHERE event_id = ? AND player_id = ? AND role_label <> ?`).run(eventId, candidate.candidate_type === 'player' ? candidate.id : -1, roleLabel);
    saveLineupAssignment(eventId, roleLabel, candidate);
    await refreshSpecificCard(interaction.channel, messageId, eventId);
    const warning = unavailableAssignmentWarning(candidate, event);
    return interaction.update(buildAutoLineupPayload(eventId, messageId, `**${roleLabel}** wurde auf **${displayName(candidate)}** gesetzt.${warning}`));
  }

  if (action === 'replacement') {
    const roleLabel = parts[4];
    const selectedValue = interaction.values[0];
    if (selectedValue === '__new_standin__') {
      return interaction.showModal(buildNewStandinModal(eventId, messageId, roleLabel));
    }

    const [selectedType, selectedIdRaw] = String(selectedValue).split(':');
    const selectedId = Number(selectedIdRaw);
    const candidate = selectedType === 'standin'
      ? db.prepare(`SELECT *, 'standin' AS candidate_type FROM standins WHERE id = ? AND is_active = 1`).get(selectedId)
      : db.prepare(`SELECT *, 'player' AS candidate_type FROM players WHERE id = ? AND is_archived = 0 AND team_id = ?`).get(selectedId, event.team_id);

    if (!candidate) {
      return interaction.update({ content: 'Die ausgewählte Person wurde nicht gefunden.', components: [] });
    }

    saveLineupAssignment(eventId, roleLabel, candidate);
    await refreshSpecificCard(interaction.channel, messageId, eventId);
    const warning = unavailableAssignmentWarning(candidate, event);
    return interaction.update(buildAutoLineupPayload(eventId, messageId, `Ersatz für **${roleLabel}**: **${displayName(candidate)}**.${warning}`));
  }

  if (action === 'lineuprole') {
    const roleLabel = interaction.values[0];
    const currentAssignment = getRoleAssignment(eventId, roleLabel);
    const infoText = currentAssignment
      ? `Aktuell ist **${roleLabel}** auf **${currentAssignment.player_label}** gesetzt.`
      : `Für **${roleLabel}** ist aktuell niemand gesetzt.`;

    return interaction.update({
      content: `${infoText}\nWähle jetzt einen Spieler oder leere die Rolle.`,
      components: [
        buildPlayerSelectRow(eventId, messageId, roleLabel),
        buildRoleSelectRow(eventId, messageId)
      ]
    });
  }

  if (action === 'lineupplayer') {
    const roleLabel = parts[4];
    const selectedValue = interaction.values[0];
    const now = new Date().toISOString();
    let infoText;

    if (selectedValue === '__clear__') {
      db.prepare(`
        DELETE FROM team_calendar_assignments
        WHERE event_id = ? AND role_label = ?
      `).run(eventId, roleLabel);

      infoText = `**${roleLabel}** wurde geleert.`;
    } else {
      const [selectedType, selectedIdRaw] = String(selectedValue).split(':');
      const selectedId = Number(selectedIdRaw || selectedValue);
      let assigneeType = selectedType;
      let assignee = null;
      let playerId = null;
      let standinId = null;
      let label = null;

      if (selectedType === 'standin') {
        assignee = db.prepare(`
          SELECT *
          FROM standins
          WHERE id = ? AND is_active = 1
        `).get(selectedId);
        standinId = assignee?.id ?? null;
        label = assignee?.display_name ?? null;
      } else {
        assigneeType = 'player';
        assignee = db.prepare(`
          SELECT *
          FROM players
          WHERE id = ?
        `).get(selectedType === 'player' ? selectedId : Number(selectedValue));
        playerId = assignee?.id ?? null;
        label = assignee ? playerDisplay(assignee) : null;
      }

      if (!assignee || !label) {
        return interaction.update({
          content: 'Die ausgewählte Person wurde nicht gefunden.',
          components: [buildRoleSelectRow(eventId, messageId)]
        });
      }

      db.prepare(`
        INSERT INTO team_calendar_assignments (
          event_id,
          role_label,
          player_label,
          assignee_type,
          player_id,
          standin_id,
          note,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
        ON CONFLICT(event_id, role_label)
        DO UPDATE SET
          player_label = excluded.player_label,
          assignee_type = excluded.assignee_type,
          player_id = excluded.player_id,
          standin_id = excluded.standin_id,
          updated_at = excluded.updated_at
      `).run(
        eventId,
        roleLabel,
        label,
        assigneeType,
        playerId,
        standinId,
        now,
        now
      );

      const warning = assigneeType === 'player' && !isPlayerAvailableForEvent(playerId, event)
        ? ' ⚠️ **Hinweis:** Dieser Spieler ist für den Termin als abwesend eingetragen.'
        : '';
      infoText = `**${roleLabel}** wurde auf **${label}**${assigneeType === 'standin' ? ' [Standin]' : ''} gesetzt.${warning}`;
    }

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.update({
      ...buildLineupManagerPayload(eventId, messageId, infoText)
    });
  }
}

async function handleModalSubmitInteraction(interaction, parts) {
  if (!ensureAdminPermission(interaction)) {
    return interaction.reply({
      content: 'Dafür fehlen dir die Rechte.',
      flags: MessageFlags.Ephemeral
    });
  }

  const action = parts[1];
  const eventId = Number(parts[2]);
  const messageId = parts[3];
  const event = getEventById(eventId);

  if (!event) {
    return interaction.reply({
      content: 'Dieser Kalendereintrag existiert nicht mehr.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'statusmodal') {
    const nextStatus = normalizeStatusInput(interaction.fields.getTextInputValue('status_value'));

    if (!nextStatus || !STATUS_VALUES.includes(nextStatus)) {
      return interaction.reply({
        content: 'Ungültiger Status. Nutze `pending`, `fixed` oder `cancelled`.',
        flags: MessageFlags.Ephemeral
      });
    }

    db.prepare(`
      UPDATE team_calendar_events
      SET status = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextStatus, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: `Status für **#${eventId}** wurde auf **${statusLabel(nextStatus)}** gesetzt.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'typemodal') {
    const nextType = normalizeEventTypeInput(interaction.fields.getTextInputValue('event_type_value'));

    if (!nextType || !EVENT_TYPE_VALUES.includes(nextType)) {
      return interaction.reply({
        content: 'Ungültiger Typ. Nutze `open`, `flex`, `scrim`, `primeleague` oder `other`.',
        flags: MessageFlags.Ephemeral
      });
    }

    db.prepare(`
      UPDATE team_calendar_events
      SET event_type = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextType, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: `Typ für **#${eventId}** wurde auf **${eventTypeLabel(nextType)}** gesetzt.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'fixedtimemodal') {
    const rawStart = interaction.fields.getTextInputValue('scheduled_start_time').trim();
    const rawEnd = interaction.fields.getTextInputValue('scheduled_end_time').trim();

    let nextScheduledStartAt = event.scheduled_start_at;
    let nextScheduledEndAt = event.scheduled_end_at;
    let nextMeetingScrimAt = event.meeting_scrim_at;
    let nextMeetingPrimeleagueAt = event.meeting_primeleague_at;

    if (rawStart === '' || rawStart === '-') {
      nextScheduledStartAt = null;
      nextScheduledEndAt = null;
      nextMeetingScrimAt = null;
      nextMeetingPrimeleagueAt = null;
    } else {
      if (!isValidTime(rawStart)) {
        return interaction.reply({
          content: 'Die Startzeit ist ungültig. Bitte nutze HH:MM.',
          flags: MessageFlags.Ephemeral
        });
      }

      const durationMinutes = getDurationMinutesFromDateTimes(
        event.scheduled_start_at || event.window_start_at,
        event.scheduled_end_at || event.window_end_at
      );

      const nextEndTime =
        rawEnd === ''
          ? addMinutesToTime(rawStart, durationMinutes)
          : rawEnd;

      if (!isValidTime(nextEndTime)) {
        return interaction.reply({
          content: 'Die Endzeit ist ungültig. Bitte nutze HH:MM.',
          flags: MessageFlags.Ephemeral
        });
      }

      nextScheduledStartAt = `${event.option_date} ${rawStart}`;
      nextScheduledEndAt = `${event.option_date} ${nextEndTime}`;

      nextMeetingScrimAt = reconcileMeetingAfterScheduleChange(
        event.meeting_scrim_at,
        event.scheduled_start_at,
        nextScheduledStartAt,
        'scrim'
      );

      nextMeetingPrimeleagueAt = reconcileMeetingAfterScheduleChange(
        event.meeting_primeleague_at,
        event.scheduled_start_at,
        nextScheduledStartAt,
        'primeleague'
      );
    }

    db.prepare(`
      UPDATE team_calendar_events
      SET scheduled_start_at = ?,
          scheduled_end_at = ?,
          meeting_scrim_at = ?,
          meeting_primeleague_at = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(
      nextScheduledStartAt,
      nextScheduledEndAt,
      nextMeetingScrimAt,
      nextMeetingPrimeleagueAt,
      interaction.user.id,
      new Date().toISOString(),
      eventId
    );

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: nextScheduledStartAt
        ? `Fixe Zeit für **#${eventId}** wurde auf **${formatDateTimeDE(nextScheduledStartAt)} → ${formatDateTimeDE(nextScheduledEndAt)}** gesetzt.`
        : `Fixe Zeit für **#${eventId}** wurde gelöscht.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'meetingmodal') {
    if (!event.scheduled_start_at) {
      return interaction.reply({
        content: 'Setze zuerst eine fixe Zeit.',
        flags: MessageFlags.Ephemeral
      });
    }

    const rawScrim = interaction.fields.getTextInputValue('meeting_scrim_time').trim();
    const rawPrime = interaction.fields.getTextInputValue('meeting_prime_time').trim();
    const dateStr = event.scheduled_start_at.slice(0, 10);

    if (rawScrim !== '' && rawScrim !== '-' && !isValidTime(rawScrim)) {
      return interaction.reply({
        content: 'Treffpunkt Scrim ist ungültig. Bitte nutze HH:MM.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (rawPrime !== '' && rawPrime !== '-' && !isValidTime(rawPrime)) {
      return interaction.reply({
        content: 'Treffpunkt Prime League ist ungültig. Bitte nutze HH:MM.',
        flags: MessageFlags.Ephemeral
      });
    }

    const nextMeetingScrimAt =
      rawScrim === '' || rawScrim === '-'
        ? null
        : `${dateStr} ${rawScrim}`;

    const nextMeetingPrimeleagueAt =
      rawPrime === '' || rawPrime === '-'
        ? null
        : `${dateStr} ${rawPrime}`;

    db.prepare(`
      UPDATE team_calendar_events
      SET meeting_scrim_at = ?,
          meeting_primeleague_at = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(
      nextMeetingScrimAt,
      nextMeetingPrimeleagueAt,
      interaction.user.id,
      new Date().toISOString(),
      eventId
    );

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    const freshEvent = getEventById(eventId);

    return interaction.reply({
      content:
        `Treffpunkt für **#${eventId}** wurde aktualisiert.\n` +
        `Aktuell: **${buildMeetingFieldValue(freshEvent)}**`,
      flags: MessageFlags.Ephemeral
    });
  }
  if (action === 'newstandin') {
    const roleLabel = parts[4];
    const displayNameValue = interaction.fields.getTextInputValue('display_name').trim();
    const riotRaw = interaction.fields.getTextInputValue('riot_id').trim();
    const regionValue = interaction.fields.getTextInputValue('riot_region').trim().toLowerCase() || 'euw';
    const noteValue = interaction.fields.getTextInputValue('note').trim() || null;
    const hashIndex = riotRaw.lastIndexOf('#');

    if (!displayNameValue || hashIndex <= 0 || hashIndex === riotRaw.length - 1) {
      return interaction.reply({ content: 'Bitte gib die Riot-ID im Format `GameName#Tag` ein.', flags: MessageFlags.Ephemeral });
    }

    const riotGameName = riotRaw.slice(0, hashIndex).trim();
    const riotTag = riotRaw.slice(hashIndex + 1).trim().toUpperCase();
    const now = new Date().toISOString();
    const existing = db.prepare(`
      SELECT * FROM standins
      WHERE lower(riot_game_name) = lower(?) AND lower(riot_tag) = lower(?) AND lower(riot_region) = lower(?)
      LIMIT 1
    `).get(riotGameName, riotTag, regionValue);

    let standinId;
    if (existing) {
      standinId = existing.id;
      db.prepare(`
        UPDATE standins SET display_name = ?, preferred_position = ?, note = ?, is_active = 1,
          updated_by_discord_user_id = ?, updated_at = ? WHERE id = ?
      `).run(displayNameValue, roleLabel, noteValue, interaction.user.id, now, standinId);
    } else {
      const result = db.prepare(`
        INSERT INTO standins (
          display_name, riot_game_name, riot_tag, riot_region, preferred_position, note,
          is_active, created_by_discord_user_id, updated_by_discord_user_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
      `).run(displayNameValue, riotGameName, riotTag, regionValue, roleLabel, noteValue, interaction.user.id, interaction.user.id, now, now);
      standinId = Number(result.lastInsertRowid);
    }

    const candidate = db.prepare(`SELECT *, 'standin' AS candidate_type FROM standins WHERE id = ?`).get(standinId);
    saveLineupAssignment(eventId, roleLabel, candidate);
    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: `Standin **${displayNameValue}** wurde gespeichert und direkt auf **${roleLabel}** gesetzt.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'lineupmodal') {
    const parsedLineup = parseLineupModalText(interaction.fields.getTextInputValue('lineup_text'));

    if (parsedLineup.size === 0) {
      return interaction.reply({
        content:
          'Ich konnte keine Rollen erkennen. Bitte nutze pro Zeile das Format `Top: Name`.',
        flags: MessageFlags.Ephemeral
      });
    }

    const changed = await applyLineupChanges(eventId, parsedLineup);
    const assignments = getAssignments(eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content:
        (changed === 0
          ? 'Es wurden keine Rollen geändert.\n'
          : `Lineup für **#${eventId}** wurde aktualisiert.\n`) +
        `Aktuell: **${buildLineupText(assignments)}**`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'opponentmodal') {
    const raw = interaction.fields.getTextInputValue('opponent_name').trim();
    const nextValue = raw === '' || raw === '-' ? null : raw;

    db.prepare(`
    UPDATE team_calendar_events
    SET opponent_name = ?,
        updated_by_discord_user_id = ?,
        updated_at = ?
    WHERE id = ?
  `).run(nextValue, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: nextValue
        ? `Gegner für **#${eventId}** wurde auf **${nextValue}** gesetzt.`
        : `Gegner für **#${eventId}** wurde gelöscht.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'enemyopggmodal') {
    const raw = interaction.fields.getTextInputValue('opgg_url').trim();
    const nextValue = raw === '' || raw === '-' ? null : raw;

    db.prepare(`
      UPDATE team_calendar_events
      SET opgg_url = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextValue, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: `Gegner-OPGG für **#${eventId}** wurde ${nextValue ? 'gespeichert' : 'gelöscht'}.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (action === 'notemodal') {
    const raw = interaction.fields.getTextInputValue('note_text').trim();
    const nextValue = raw === '' || raw === '-' ? null : raw;

    db.prepare(`
      UPDATE team_calendar_events
      SET note = ?,
          updated_by_discord_user_id = ?,
          updated_at = ?
      WHERE id = ?
    `).run(nextValue, interaction.user.id, new Date().toISOString(), eventId);

    await refreshSpecificCard(interaction.channel, messageId, eventId);

    return interaction.reply({
      content: `Hinweis für **#${eventId}** wurde ${nextValue ? 'gespeichert' : 'gelöscht'}.`,
      flags: MessageFlags.Ephemeral
    });
  }
}

const command = {
  data: new SlashCommandBuilder()
    .setName('spieltermin')
    .setDescription('Verwalte den Spielerkalender.')

    .addSubcommand(sub =>
      sub
        .setName('anzeigen')
        .setDescription('Zeigt die nächsten Spieltermine an.')
    )

    .addSubcommand(sub =>
      sub
        .setName('pruefen')
        .setDescription('Prüft ein konkretes Datum und eine Uhrzeit auf Verfügbarkeit.')
        .addStringOption(option =>
          option
            .setName('datum')
            .setDescription('Datum als TT.MM.JJJJ oder YYYY-MM-DD')
            .setRequired(true)
        )
        .addStringOption(option =>
          option
            .setName('startzeit')
            .setDescription('Startzeit im Format HH:MM')
            .setRequired(true)
        )
        .addIntegerOption(option =>
          option
            .setName('dauer_minuten')
            .setDescription('Dauer in Minuten, Standard: 150')
            .setRequired(false)
            .setMinValue(30)
            .setMaxValue(720)
        )
        .addStringOption(option =>
          option
            .setName('typ')
            .setDescription('Optionaler Termin-Typ für die Vorschau')
            .setRequired(false)
            .addChoices(
              { name: 'Offen', value: 'open' },
              { name: 'Flex', value: 'flex' },
              { name: 'Scrim', value: 'scrim' },
              { name: 'Prime League', value: 'primeleague' },
              { name: 'Sonstiges', value: 'other' }
            )
        )
    )

    .addSubcommand(sub =>
      sub
        .setName('erstellen')
        .setDescription('Erstellt einen neuen Spieltermin oder eine Vormerkung.')
        .addStringOption(option =>
          option
            .setName('datum')
            .setDescription('Datum als TT.MM.JJJJ oder YYYY-MM-DD')
            .setRequired(true)
        )

        .addStringOption(option =>
          option
            .setName('startzeit')
            .setDescription('Startzeit im Format HH:MM')
            .setRequired(true)
        )
        .addStringOption(option =>
          option
            .setName('titel')
            .setDescription('Titel des Termins')
            .setRequired(true)
        )
        .addIntegerOption(option =>
          option
            .setName('dauer_minuten')
            .setDescription('Dauer in Minuten, Standard: 150')
            .setRequired(false)
            .setMinValue(30)
            .setMaxValue(720)
        )
        .addStringOption(option =>
          option
            .setName('gegner')
            .setDescription('Optional: Gegnername')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('typ')
            .setDescription('Typ des Termins')
            .setRequired(false)
            .addChoices(
              { name: 'Offen', value: 'open' },
              { name: 'Flex', value: 'flex' },
              { name: 'Scrim', value: 'scrim' },
              { name: 'Prime League', value: 'primeleague' },
              { name: 'Sonstiges', value: 'other' }
            )
        )
        .addStringOption(option =>
          option
            .setName('status')
            .setDescription('Status des Termins')
            .setRequired(false)
            .addChoices(
              { name: 'Pending', value: 'pending' },
              { name: 'Fixed', value: 'fixed' },
              { name: 'Cancelled', value: 'cancelled' }
            )
        )
        .addStringOption(option =>
          option
            .setName('hinweis')
            .setDescription('Optional: Hinweistext')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('opgg')
            .setDescription('Optional: Gegner-OPGG-Link')
            .setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('loeschen')
        .setDescription('Löscht einen Spieltermin endgültig.')
        .addIntegerOption(option =>
          option
            .setName('id')
            .setDescription('Kalender-ID des zu löschenden Termins')
            .setRequired(true)
        )
    )

    .addSubcommand(sub =>
      sub
        .setName('bearbeiten')
        .setDescription('Bearbeitet einen Kalendereintrag anhand der ID.')
        .addIntegerOption(option =>
          option
            .setName('id')
            .setDescription('Kalender-ID aus dem Planner oder aus /spieltermin anzeigen')
            .setRequired(true)
        )
        .addStringOption(option =>
          option
            .setName('datum')
            .setDescription('Optional: neues Datum, TT.MM.JJJJ oder YYYY-MM-DD')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('startzeit')
            .setDescription('Optional: exakte Startzeit im Format HH:MM')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('titel')
            .setDescription('Optional: neuer Titel')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('gegner')
            .setDescription('Optional: Gegnername, mit "-" wird gelöscht')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('typ')
            .setDescription('Optional: neuer Typ')
            .setRequired(false)
            .addChoices(
              { name: 'Offen', value: 'open' },
              { name: 'Flex', value: 'flex' },
              { name: 'Scrim', value: 'scrim' },
              { name: 'Prime League', value: 'primeleague' },
              { name: 'Sonstiges', value: 'other' }
            )
        )
        .addStringOption(option =>
          option
            .setName('status')
            .setDescription('Optional: neuer Status')
            .setRequired(false)
            .addChoices(
              { name: 'Pending', value: 'pending' },
              { name: 'Fixed', value: 'fixed' },
              { name: 'Cancelled', value: 'cancelled' }
            )
        )
        .addStringOption(option =>
          option
            .setName('hinweis')
            .setDescription('Optional: Hinweistext, mit "-" wird gelöscht')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('opgg')
            .setDescription('Optional: OPGG-Link des Gegners, mit "-" wird gelöscht')
            .setRequired(false)
        )
    )

    .addSubcommand(sub =>
      sub
        .setName('lineup')
        .setDescription('Setzt die flexible Rollenverteilung für einen Termin.')
        .addIntegerOption(option =>
          option
            .setName('id')
            .setDescription('Kalender-ID')
            .setRequired(true)
        )
        .addStringOption(option => option.setName('top').setDescription('Spieler für Top').setRequired(false))
        .addStringOption(option => option.setName('jgl').setDescription('Spieler für Jungle').setRequired(false))
        .addStringOption(option => option.setName('mid').setDescription('Spieler für Mid').setRequired(false))
        .addStringOption(option => option.setName('adc').setDescription('Spieler für ADC').setRequired(false))
        .addStringOption(option => option.setName('supp').setDescription('Spieler für Support').setRequired(false))
        .addStringOption(option => option.setName('sub1').setDescription('Optional: erster Ersatz').setRequired(false))
        .addStringOption(option => option.setName('sub2').setDescription('Optional: zweiter Ersatz').setRequired(false))
    ),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const adminOnlySubcommands = new Set(['pruefen', 'bearbeiten', 'lineup', 'erstellen', 'loeschen']);

    if (adminOnlySubcommands.has(subcommand) && !ensureAdminPermission(interaction)) {
      return interaction.reply({
        content: 'Dafür fehlen dir die Rechte, Bro. Entwickle dich erstmal zu Schillok und dann reden wir weiter!',
        flags: MessageFlags.Ephemeral
      });
    }

    if (subcommand === 'anzeigen') {
      const today = new Date().toISOString().slice(0, 10);

      const events = db.prepare(`
        SELECT *
        FROM team_calendar_events
        WHERE option_date >= ?
        ORDER BY option_date ASC, COALESCE(scheduled_start_at, window_start_at) ASC
        LIMIT 20
      `).all(today);

      if (events.length === 0) {
        return interaction.reply({
          content: 'Im Spielerkalender sind aktuell keine Termine gespeichert.',
          flags: MessageFlags.Ephemeral
        });
      }

      const lines = [];

      for (const event of events) {
        const assignments = getAssignments(event.id);
        const exactTime =
          event.scheduled_start_at && event.scheduled_end_at
            ? `${formatDateTimeDE(event.scheduled_start_at)} → ${formatDateTimeDE(event.scheduled_end_at)}`
            : '-';

        lines.push(
          `**#${event.id}** • [${statusLabel(event.status)}] ${event.title}\n` +
          `Tag: **${formatDateLongDE(event.option_date)}**\n` +
          `Fenster: **${formatDateTimeDE(event.window_start_at)} → ${formatDateTimeDE(event.window_end_at)}**\n` +
          `Fixe Zeit: **${exactTime}**\n` +
          `Typ: **${eventTypeLabel(event.event_type)}**\n` +
          `Verfügbare Spieler: **${event.available_players_text ?? '-'}**\n` +
          `Lineup: **${buildLineupText(assignments)}**\n` +
          `Gegner OPGG: **${event.opgg_url ?? '-'}**\n` +
          `Team OPGG: **${buildTeamOpggInfo(assignments).ok ? 'automatisch generierbar' : '-'}**\n` +
          `Hinweis: **${event.note ?? '-'}**`
        );
      }

      return interaction.reply({
        content: lines.join('\n\n'),
        flags: MessageFlags.Ephemeral
      });
    }
    if (subcommand === 'erstellen') {
      const datumInput = interaction.options.getString('datum', true);
      const startzeit = interaction.options.getString('startzeit', true).trim();
      const dauerMinuten = interaction.options.getInteger('dauer_minuten') ?? 150;
      const titel = interaction.options.getString('titel', true).trim();
      const gegner = interaction.options.getString('gegner');
      const typ = interaction.options.getString('typ') ?? 'other';
      const status = interaction.options.getString('status') ?? 'fixed';
      const hinweis = interaction.options.getString('hinweis');
      const opgg = interaction.options.getString('opgg');

      const parsedDate = parseDateInput(datumInput);
      if (!parsedDate) {
        return interaction.reply({
          content: 'Datum ungültig. Nutze TT.MM.JJJJ oder YYYY-MM-DD.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (!isValidTime(startzeit)) {
        return interaction.reply({
          content: 'Startzeit ungültig. Bitte nutze HH:MM, z. B. 20:00.',
          flags: MessageFlags.Ephemeral
        });
      }

      const nextOpponent = gegner?.trim() ? gegner.trim() : null;
      const nextHint = hinweis?.trim() ? hinweis.trim() : null;
      const nextOpgg = opgg?.trim() ? opgg.trim() : null;

      const startAt = buildDateTime(parsedDate, startzeit);
      const endAt = buildDateTime(parsedDate, addMinutesToTime(startzeit, dauerMinuten));
      const meetingScrimAt = getDefaultMeetingAtFromScheduledStart(startAt, 'scrim');
      const meetingPrimeleagueAt = getDefaultMeetingAtFromScheduledStart(startAt, 'primeleague');
      const legacyMeetingAt = getLegacyMeetingAtForCreate(
        typ,
        startAt,
        meetingScrimAt,
        meetingPrimeleagueAt
      );
      const now = new Date().toISOString();

      const result = db.prepare(`
  INSERT INTO team_calendar_events (
    team_id,
    title,
    opponent_name,
    event_type,
    status,
    option_date,
    window_start_at,
    window_end_at,
    scheduled_start_at,
    scheduled_end_at,
    meeting_scrim_at,
    meeting_primeleague_at,
    available_players_text,
    opgg_url,
    note,
    suggestion_key,
    is_auto_generated,
    show_in_player_calendar,
    start_at,
    end_at,
    meeting_at,
    created_by_discord_user_id,
    updated_by_discord_user_id,
    created_at,
    updated_at
  )
  VALUES (
    ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?,
    NULL, ?, ?, NULL, 0, 0,
    ?, ?, ?,
    ?, ?, ?, ?
  )
`).run(
        resolveTeamForInteraction(interaction)?.id || null,
        titel,
        nextOpponent,
        typ,
        status,
        parsedDate,
        startAt,
        endAt,
        startAt,
        endAt,
        meetingScrimAt,
        meetingPrimeleagueAt,
        nextOpgg,
        nextHint,
        startAt,
        endAt,
        legacyMeetingAt,
        interaction.user.id,
        interaction.user.id,
        now,
        now
      );

      const id = Number(result.lastInsertRowid);
      return interaction.reply({
        content:
          `Spieltermin **#${id}** wurde erstellt.\n` +
          `Titel: **${titel}**\n` +
          `Gegner: **${nextOpponent ?? '-'}**\n` +
          `Typ: **${eventTypeLabel(typ)}**\n` +
          `Status: **${statusLabel(status)}**\n` +
          `Zeit: **${formatDateTimeDE(startAt)}**\n` +
          `Hinweis: **${nextHint ?? '-'}**\n` +
          `Admin-Karte: **wird erst zum Wochenstart erzeugt**`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (subcommand === 'loeschen') {
      const id = interaction.options.getInteger('id', true);
      const event = getEventById(id);

      if (!event) {
        return interaction.reply({
          content: 'Ich habe keinen Kalendereintrag mit dieser ID gefunden.',
          flags: MessageFlags.Ephemeral
        });
      }

      await deleteStoredAdminCard(interaction.client, id);
      await deleteStoredPlayerCard(interaction.client, id);

      db.prepare(`
    DELETE FROM team_calendar_assignments
    WHERE event_id = ?
  `).run(id);

      db.prepare(`
    DELETE FROM team_calendar_events
    WHERE id = ?
  `).run(id);

      return interaction.reply({
        content:
          `Spieltermin **#${id}** wurde endgültig gelöscht.\n` +
          `Titel: **${event.title}**\n` +
          `Gegner: **${event.opponent_name ?? '-'}**`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (subcommand === 'bearbeiten') {
      const id = interaction.options.getInteger('id', true);
      const datumInput = interaction.options.getString('datum');
      const startzeit = interaction.options.getString('startzeit');
      const titel = interaction.options.getString('titel');
      const gegner = interaction.options.getString('gegner');
      const typ = interaction.options.getString('typ');
      const status = interaction.options.getString('status');
      const hinweis = interaction.options.getString('hinweis');
      const opgg = interaction.options.getString('opgg');

      const event = getEventById(id);

      if (!event) {
        return interaction.reply({
          content: 'Ich habe keinen Kalendereintrag mit dieser ID gefunden.',
          flags: MessageFlags.Ephemeral
        });
      }

      const parsedDate = datumInput ? parseDateInput(datumInput) : event.option_date;
      if (datumInput && !parsedDate) {
        return interaction.reply({
          content: 'Datum ungültig. Nutze TT.MM.JJJJ oder YYYY-MM-DD.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (startzeit && !isValidTime(startzeit)) {
        return interaction.reply({
          content: 'Startzeit ungültig. Bitte nutze HH:MM, z. B. 18:30.',
          flags: MessageFlags.Ephemeral
        });
      }

      const nextTitle = titel?.trim() || event.title;
      const nextOpponent =
        gegner === null
          ? event.opponent_name
          : (gegner.trim() === '-' ? null : gegner.trim());
      const nextType = typ ?? event.event_type;
      const nextStatus = status ?? event.status;
      const nextDate = parsedDate;

      let nextWindowStartAt = event.window_start_at;
      let nextWindowEndAt = event.window_end_at;
      let nextScheduledStartAt = event.scheduled_start_at;
      let nextScheduledEndAt = event.scheduled_end_at;
      let nextMeetingScrimAt = event.meeting_scrim_at;
      let nextMeetingPrimeleagueAt = event.meeting_primeleague_at;

      if (datumInput) {
        const oldWindowStartTime = event.window_start_at.slice(11, 16);
        const oldWindowEndTime = event.window_end_at.slice(11, 16);
        nextWindowStartAt = `${nextDate} ${oldWindowStartTime}`;
        nextWindowEndAt = `${nextDate} ${oldWindowEndTime}`;

        if (event.scheduled_start_at && event.scheduled_end_at) {
          const oldStartTime = event.scheduled_start_at.slice(11, 16);
          const oldEndTime = event.scheduled_end_at.slice(11, 16);
          nextScheduledStartAt = `${nextDate} ${oldStartTime}`;
          nextScheduledEndAt = `${nextDate} ${oldEndTime}`;
        }
      }

      if (startzeit) {
        const durationMinutes = getDurationMinutesFromDateTimes(
          event.scheduled_start_at || event.window_start_at,
          event.scheduled_end_at || event.window_end_at
        );

        const endzeit = addMinutesToTime(startzeit, durationMinutes);
        nextScheduledStartAt = `${nextDate} ${startzeit}`;
        nextScheduledEndAt = `${nextDate} ${endzeit}`;
      }

      if (nextScheduledStartAt) {
        nextMeetingScrimAt = reconcileMeetingAfterScheduleChange(
          event.meeting_scrim_at,
          event.scheduled_start_at,
          nextScheduledStartAt,
          'scrim'
        );

        nextMeetingPrimeleagueAt = reconcileMeetingAfterScheduleChange(
          event.meeting_primeleague_at,
          event.scheduled_start_at,
          nextScheduledStartAt,
          'primeleague'
        );
      }

      const nextHint =
        hinweis === null
          ? event.note
          : (hinweis.trim() === '-' ? null : hinweis.trim());

      const nextOpgg =
        opgg === null
          ? event.opgg_url
          : (opgg.trim() === '-' ? null : opgg.trim());

      db.prepare(`
        UPDATE team_calendar_events
        SET title = ?,
            opponent_name = ?,
            event_type = ?,
            status = ?,
            option_date = ?,
            window_start_at = ?,
            window_end_at = ?,
            scheduled_start_at = ?,
            scheduled_end_at = ?,
            meeting_scrim_at = ?,
            meeting_primeleague_at = ?,
            note = ?,
            opgg_url = ?,
            updated_by_discord_user_id = ?,
            updated_at = ?
        WHERE id = ?
      `).run(
        nextTitle,
        nextOpponent,
        nextType,
        nextStatus,
        nextDate,
        nextWindowStartAt,
        nextWindowEndAt,
        nextScheduledStartAt,
        nextScheduledEndAt,
        nextMeetingScrimAt,
        nextMeetingPrimeleagueAt,
        nextHint,
        nextOpgg,
        interaction.user.id,
        new Date().toISOString(),
        id
      );

      await refreshStoredEventCard(interaction.client, id);

      return interaction.reply({
        content:
          `Spieltermin **#${id}** wurde aktualisiert.\n` +
          `Titel: **${nextTitle}**\n` +
          `Gegner: **${nextOpponent ?? '-'}**\n` +
          `Status: **${statusLabel(nextStatus)}**\n` +
          `Typ: **${eventTypeLabel(nextType)}**\n` +
          `Fenster: **${formatDateTimeDE(nextWindowStartAt)} → ${formatDateTimeDE(nextWindowEndAt)}**\n` +
          `Fixe Zeit: **${nextScheduledStartAt ? `${formatDateTimeDE(nextScheduledStartAt)} → ${formatDateTimeDE(nextScheduledEndAt)}` : '-'}**\n` +
          `Gegner OPGG: **${nextOpgg ?? '-'}**\n` +
          `Hinweis: **${nextHint ?? '-'}**`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (subcommand === 'lineup') {
      const id = interaction.options.getInteger('id', true);
      const event = getEventById(id);

      if (!event) {
        return interaction.reply({
          content: 'Ich habe keinen Kalendereintrag mit dieser ID gefunden.',
          flags: MessageFlags.Ephemeral
        });
      }

      const lineupEvent = getEventById(id);
      const lineupTeamId = lineupEvent?.team_id ?? null;
      const roleMap = {
        Top: interaction.options.getString('top'),
        Jgl: interaction.options.getString('jgl'),
        Mid: interaction.options.getString('mid'),
        ADC: interaction.options.getString('adc'),
        Supp: interaction.options.getString('supp'),
        Sub1: interaction.options.getString('sub1'),
        Sub2: interaction.options.getString('sub2')
      };

      const now = new Date().toISOString();
      let changed = 0;

      for (const [roleLabel, value] of Object.entries(roleMap)) {
        if (value === null) continue;

        const trimmed = value.trim();

        if (trimmed === '-' || trimmed === '') {
          db.prepare(`
            DELETE FROM team_calendar_assignments
            WHERE event_id = ?
              AND role_label = ?
          `).run(id, roleLabel);
          changed++;
          continue;
        }

        const matchedPlayer = findPlayerByLabel(trimmed, lineupTeamId);
        const matchedStandin = matchedPlayer ? null : findStandinByLabel(trimmed);
        const assigneeType = matchedPlayer ? 'player' : matchedStandin ? 'standin' : 'manual';
        const playerLabel = matchedPlayer
          ? playerDisplay(matchedPlayer)
          : matchedStandin
            ? matchedStandin.display_name
            : trimmed;

        db.prepare(`
          INSERT INTO team_calendar_assignments (
            event_id,
            role_label,
            player_label,
            assignee_type,
            player_id,
            standin_id,
            note,
            created_at,
            updated_at
          )
          VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
          ON CONFLICT(event_id, role_label)
          DO UPDATE SET
            player_label = excluded.player_label,
            assignee_type = excluded.assignee_type,
            player_id = excluded.player_id,
            standin_id = excluded.standin_id,
            updated_at = excluded.updated_at
        `).run(
          id,
          roleLabel,
          playerLabel,
          assigneeType,
          matchedPlayer?.id ?? null,
          matchedStandin?.id ?? null,
          now,
          now
        );
        changed++;
      }

      const assignments = getAssignments(id);
      await refreshStoredEventCard(interaction.client, id);

      return interaction.reply({
        content:
          (changed === 0
            ? 'Es wurden keine Rollen geändert.\n'
            : `Lineup für **#${id}** wurde aktualisiert.\n`) +
          `Aktuell: **${buildLineupText(assignments)}**`,
        flags: MessageFlags.Ephemeral
      });
    }
  },

  canHandleInteraction(interaction) {
    return Boolean(interaction.customId && interaction.customId.startsWith('spieltermin:'));
  },

  async handleInteraction(interaction) {
    const parts = parsePlannerCustomId(interaction.customId);
    if (!parts) return false;

    if (interaction.isButton()) {
      await handleButtonInteraction(interaction, parts);
      return true;
    }

    if (interaction.isStringSelectMenu()) {
      await handleStringSelectInteraction(interaction, parts);
      return true;
    }

    if (interaction.isModalSubmit()) {
      await handleModalSubmitInteraction(interaction, parts);
      return true;
    }

    return false;
  },

  buildEventCardPayload,
  upsertAdminCardMessage,
  refreshAllStoredAdminCards,
  refreshStoredEventCard,
  statusLabel,
  eventTypeLabel,
  buildLineupText
};

module.exports = command;
